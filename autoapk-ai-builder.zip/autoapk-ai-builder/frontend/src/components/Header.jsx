import React from 'react';
import { motion } from 'framer-motion';
import { Cpu, Zap } from 'lucide-react';

export default function Header() {
  return (
    <motion.header
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="mb-12 pt-4"
    >
      <div className="flex items-center gap-3 mb-3">
        <div className="relative">
          <div className="w-10 h-10 bg-acid-500/10 border border-acid-500/30 rounded flex items-center justify-center">
            <Cpu className="w-5 h-5 text-acid-400" />
          </div>
          <span className="absolute -top-1 -right-1 w-3 h-3 bg-acid-500 rounded-full animate-pulse" />
        </div>
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight text-white">
            AUTO<span className="text-acid-400 text-glow-acid">APK</span>
            <span className="text-slate-500 ml-2 text-lg font-normal">AI Builder</span>
          </h1>
        </div>
      </div>

      <div className="flex items-center gap-6 text-xs font-mono text-slate-500 border-t border-void-600 pt-4 mt-4">
        <span className="flex items-center gap-1.5">
          <Zap className="w-3 h-3 text-acid-500" />
          AI-Powered Error Fixing
        </span>
        <span className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-acid-500 animate-pulse" />
          Docker Sandboxed
        </span>
        <span className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-plasma-400" />
          Gradle · Flutter · React Native
        </span>
      </div>
    </motion.header>
  );
}
