import React from 'react';
import { motion } from 'framer-motion';
import { Check, Loader2 } from 'lucide-react';

export default function StepPipeline({ steps, current, status }) {
  const currentIdx = steps.findIndex(s => s.id === current.id);

  return (
    <div className="glass rounded-lg p-4">
      <div className="flex items-center">
        {steps.map((step, idx) => {
          const isDone = idx < currentIdx || (status === 'completed');
          const isActive = step.id === current.id && status === 'active';
          const isFailed = step.id === current.id && status === 'failed';

          return (
            <React.Fragment key={step.id}>
              {/* Node */}
              <div className="flex flex-col items-center gap-1.5 flex-shrink-0">
                <motion.div
                  animate={isActive ? { scale: [1, 1.1, 1] } : {}}
                  transition={{ duration: 1.5, repeat: Infinity }}
                  className={`
                    w-8 h-8 rounded-full border-2 flex items-center justify-center text-xs transition-all duration-300
                    ${isDone
                      ? 'bg-acid-500/20 border-acid-500 text-acid-400'
                      : isActive
                      ? 'bg-acid-500/10 border-acid-400 text-acid-400'
                      : isFailed
                      ? 'bg-red-500/10 border-red-500 text-red-400'
                      : 'bg-void-700 border-void-600 text-slate-600'}
                  `}
                >
                  {isDone ? (
                    <Check className="w-3.5 h-3.5" />
                  ) : isActive ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <span className="font-mono">{idx + 1}</span>
                  )}
                </motion.div>

                <span className={`text-xs font-mono whitespace-nowrap transition-colors duration-300 ${
                  isDone ? 'text-acid-400' :
                  isActive ? 'text-white' :
                  isFailed ? 'text-red-400' :
                  'text-slate-600'
                }`}>
                  {step.label}
                </span>
              </div>

              {/* Connector */}
              {idx < steps.length - 1 && (
                <div className="flex-1 mx-1 mb-5">
                  <div className="h-px bg-void-600 relative overflow-hidden">
                    <motion.div
                      className="absolute inset-y-0 left-0 bg-acid-500/60"
                      initial={{ width: 0 }}
                      animate={{ width: isDone ? '100%' : '0%' }}
                      transition={{ duration: 0.5, delay: 0.1 }}
                    />
                  </div>
                </div>
              )}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
}
