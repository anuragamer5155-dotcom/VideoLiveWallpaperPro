import React, { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { Terminal, ChevronDown, ChevronUp, Copy, Check } from 'lucide-react';

const LEVEL_STYLES = {
  info:  'text-slate-300',
  warn:  'text-yellow-400',
  error: 'text-red-400',
  debug: 'text-slate-500',
};

function classifyLine(msg) {
  if (!msg) return 'info';
  const lower = msg.toLowerCase();
  if (lower.includes('error') || lower.includes('exception') || lower.includes('failed')) return 'error';
  if (lower.includes('warn') || lower.includes('deprecated')) return 'warn';
  if (lower.includes('✅') || lower.includes('success') || lower.includes('complete')) return 'info';
  return 'info';
}

export default function LogViewer({ logs, status }) {
  const bottomRef = useRef(null);
  const containerRef = useRef(null);
  const [autoScroll, setAutoScroll] = useState(true);
  const [collapsed, setCollapsed] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (autoScroll && bottomRef.current && !collapsed) {
      bottomRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [logs, autoScroll, collapsed]);

  const handleScroll = () => {
    const el = containerRef.current;
    if (!el) return;
    const atBottom = el.scrollTop + el.clientHeight >= el.scrollHeight - 40;
    setAutoScroll(atBottom);
  };

  const copyLogs = () => {
    const text = logs.map(l => `[${l.ts || ''}] ${l.msg}`).join('\n');
    navigator.clipboard.writeText(text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const isActive = status === 'active';

  return (
    <motion.div
      layout
      className="glass rounded-lg overflow-hidden"
    >
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-void-600">
        <div className="flex items-center gap-2">
          <Terminal className="w-4 h-4 text-acid-400" />
          <span className="font-display text-sm font-bold text-slate-300">Build Output</span>
          <span className="text-xs font-mono text-slate-600">
            {logs.length} lines
          </span>
          {isActive && (
            <span className="flex items-center gap-1 text-xs font-mono text-acid-500">
              <span className="w-1.5 h-1.5 rounded-full bg-acid-500 animate-pulse" />
              LIVE
            </span>
          )}
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={copyLogs}
            className="p-1.5 rounded hover:bg-void-600 transition-colors text-slate-500 hover:text-slate-300"
            title="Copy logs"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-acid-400" /> : <Copy className="w-3.5 h-3.5" />}
          </button>
          <button
            onClick={() => setCollapsed(c => !c)}
            className="p-1.5 rounded hover:bg-void-600 transition-colors text-slate-500 hover:text-slate-300"
          >
            {collapsed
              ? <ChevronDown className="w-3.5 h-3.5" />
              : <ChevronUp className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Log body */}
      {!collapsed && (
        <div
          ref={containerRef}
          onScroll={handleScroll}
          className="h-80 overflow-y-auto p-3 space-y-px"
          style={{ fontFamily: "'JetBrains Mono', monospace" }}
        >
          {logs.length === 0 ? (
            <div className="flex items-center gap-2 text-slate-600 text-xs py-4 justify-center">
              <span className="animate-pulse">Waiting for build output</span>
              <span className="cursor-blink text-acid-500">█</span>
            </div>
          ) : (
            logs.map((entry) => (
              <LogLine key={entry.id} entry={entry} />
            ))
          )}
          {isActive && (
            <div className="flex items-center gap-1 text-xs text-slate-600 pt-1">
              <span className="cursor-blink text-acid-500">█</span>
            </div>
          )}
          <div ref={bottomRef} />
        </div>
      )}

      {/* Scroll-to-bottom button */}
      {!collapsed && !autoScroll && (
        <div className="absolute bottom-16 right-6">
          <button
            onClick={() => {
              setAutoScroll(true);
              bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="flex items-center gap-1 text-xs bg-void-700 border border-void-600 rounded px-2 py-1 text-slate-400 hover:text-slate-200"
          >
            <ChevronDown className="w-3 h-3" />
            Jump to bottom
          </button>
        </div>
      )}
    </motion.div>
  );
}

function LogLine({ entry }) {
  const level = entry.level || classifyLine(entry.msg);
  const style = LEVEL_STYLES[level] || LEVEL_STYLES.info;

  const ts = entry.ts ? new Date(entry.ts).toLocaleTimeString('en', { hour12: false }) : '';

  return (
    <div className={`flex gap-2 text-xs leading-5 group ${style}`}>
      <span className="text-slate-700 flex-shrink-0 group-hover:text-slate-500 transition-colors select-none w-16">
        {ts}
      </span>
      <span className="break-all whitespace-pre-wrap">{entry.msg}</span>
    </div>
  );
}
