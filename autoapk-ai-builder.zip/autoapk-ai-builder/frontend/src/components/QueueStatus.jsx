import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import axios from 'axios';
import { Activity, Clock, CheckCircle2, XCircle, Zap } from 'lucide-react';

export default function QueueStatus() {
  const [stats, setStats] = useState(null);

  useEffect(() => {
    const fetch = async () => {
      try {
        const res = await axios.get('/api/status/queue');
        setStats(res.data);
      } catch (_) {}
    };

    fetch();
    const interval = setInterval(fetch, 5000);
    return () => clearInterval(interval);
  }, []);

  if (!stats) return null;

  const items = [
    { label: 'Active',    value: stats.active,    icon: Zap,          color: 'text-acid-400'  },
    { label: 'Waiting',   value: stats.waiting,   icon: Clock,        color: 'text-yellow-400' },
    { label: 'Completed', value: stats.completed, icon: CheckCircle2, color: 'text-slate-400' },
    { label: 'Failed',    value: stats.failed,    icon: XCircle,      color: 'text-red-400'   },
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.5 }}
      className="glass rounded-lg p-4"
    >
      <div className="flex items-center gap-2 mb-3">
        <Activity className="w-4 h-4 text-slate-500" />
        <span className="font-display text-xs font-bold text-slate-500 uppercase tracking-widest">
          Queue Status
        </span>
      </div>
      <div className="grid grid-cols-4 gap-3">
        {items.map(({ label, value, icon: Icon, color }) => (
          <div key={label} className="flex flex-col items-center gap-1">
            <Icon className={`w-4 h-4 ${color}`} />
            <span className={`text-xl font-display font-bold ${color}`}>{value}</span>
            <span className="text-xs text-slate-600 font-mono">{label}</span>
          </div>
        ))}
      </div>
    </motion.div>
  );
}
