import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowLeft, Download, CheckCircle2, XCircle, Loader2,
  Terminal, Cpu, Wrench, Package, Zap, RefreshCw
} from 'lucide-react';
import { io } from 'socket.io-client';
import StepPipeline from './StepPipeline.jsx';
import LogViewer from './LogViewer.jsx';

const STEPS = [
  { id: 'upload',   label: 'Upload',    icon: '↑',  pct: 0   },
  { id: 'extract',  label: 'Extract',   icon: '📦', pct: 10  },
  { id: 'analyze',  label: 'Analyze',   icon: '🔍', pct: 20  },
  { id: 'build',    label: 'Build',     icon: '🔨', pct: 50  },
  { id: 'fix',      label: 'AI Fix',    icon: '🤖', pct: 70  },
  { id: 'package',  label: 'Package',   icon: '📁', pct: 90  },
  { id: 'done',     label: 'Done',      icon: '✓',  pct: 100 },
];

export default function BuildDashboard({ jobId, projectType, fileName, onReset }) {
  const [logs, setLogs] = useState([]);
  const [currentStep, setCurrentStep] = useState({ id: 'upload', label: 'Queued', pct: 0 });
  const [progress, setProgress] = useState(0);
  const [status, setStatus] = useState('active'); // active | completed | failed
  const [downloadInfo, setDownloadInfo] = useState(null);
  const [errorMsg, setErrorMsg] = useState('');
  const socketRef = useRef(null);

  useEffect(() => {
    const socket = io(window.location.origin, { transports: ['websocket', 'polling'] });
    socketRef.current = socket;

    socket.on('connect', () => {
      socket.emit('subscribe', jobId);
      addLog({ msg: `Connected — subscribed to job ${jobId}`, level: 'info', ts: new Date().toISOString() });
    });

    socket.on('subscribed', () => {
      addLog({ msg: `Build in queue. Waiting for worker...`, level: 'info', ts: new Date().toISOString() });
    });

    socket.on('log', (entry) => {
      addLog(entry);
    });

    socket.on('step', (step) => {
      setCurrentStep(step);
      setProgress(step.pct || 0);
    });

    socket.on('complete', (data) => {
      setStatus('completed');
      setProgress(100);
      setDownloadInfo(data);
      setCurrentStep({ id: 'done', label: 'Build Complete', pct: 100 });
    });

    socket.on('error', (data) => {
      setStatus('failed');
      setErrorMsg(data.message || 'Build failed.');
    });

    socket.on('disconnect', () => {
      addLog({ msg: 'Disconnected from server', level: 'warn', ts: new Date().toISOString() });
    });

    return () => socket.disconnect();
  }, [jobId]);

  const addLog = (entry) => {
    setLogs(prev => [...prev.slice(-1000), { ...entry, id: Math.random() }]);
  };

  const handleDownload = () => {
    if (downloadInfo?.downloadUrl) {
      window.location.href = downloadInfo.downloadUrl;
    }
  };

  return (
    <div className="space-y-5">
      {/* Header bar */}
      <div className="flex items-center justify-between">
        <button
          onClick={onReset}
          className="flex items-center gap-2 text-sm text-slate-500 hover:text-slate-300 transition-colors font-mono"
        >
          <ArrowLeft className="w-4 h-4" />
          New Build
        </button>

        <div className="flex items-center gap-3">
          <span className="text-xs font-mono text-slate-600">{fileName}</span>
          <span className="text-xs font-mono px-2 py-0.5 rounded border border-void-600 text-slate-400">
            {projectType}
          </span>
          <span className="text-xs font-mono text-slate-600">
            #{jobId.slice(0, 8)}
          </span>
        </div>
      </div>

      {/* Step pipeline */}
      <StepPipeline steps={STEPS} current={currentStep} status={status} />

      {/* Progress bar */}
      <div className="glass rounded-lg p-4">
        <div className="flex justify-between text-xs font-mono text-slate-500 mb-2">
          <span>{currentStep.label}</span>
          <span>{progress}%</span>
        </div>
        <div className="h-2 bg-void-700 rounded-full overflow-hidden">
          <motion.div
            className={`h-full rounded-full ${
              status === 'failed' ? 'bg-red-500' :
              status === 'completed' ? 'bg-acid-500' :
              'bg-acid-500 progress-active'
            }`}
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ ease: 'easeOut', duration: 0.5 }}
          />
        </div>
      </div>

      {/* Status cards */}
      <AnimatePresence>
        {status === 'completed' && downloadInfo && (
          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            className="glass rounded-lg p-5 border border-acid-500/30 glow-acid"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-acid-500/10 border border-acid-500/30 flex items-center justify-center">
                  <CheckCircle2 className="w-5 h-5 text-acid-400" />
                </div>
                <div>
                  <p className="font-display font-bold text-white">APK Built Successfully</p>
                  <p className="text-sm text-slate-400 mt-0.5">
                    Size: {downloadInfo.sizeMB} MB · Ready to install
                  </p>
                </div>
              </div>
              <motion.button
                onClick={handleDownload}
                whileTap={{ scale: 0.95 }}
                className="btn-acid flex items-center gap-2"
              >
                <Download className="w-4 h-4" />
                Download APK
              </motion.button>
            </div>
          </motion.div>
        )}

        {status === 'failed' && (
          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            className="glass rounded-lg p-5 border border-red-500/30"
          >
            <div className="flex items-start gap-3">
              <XCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
              <div className="flex-1 min-w-0">
                <p className="font-display font-bold text-red-400">Build Failed</p>
                <p className="text-sm text-slate-400 mt-1 break-words">{errorMsg}</p>
              </div>
              <button
                onClick={onReset}
                className="btn-ghost text-sm flex items-center gap-1.5 flex-shrink-0"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Retry
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Live log viewer */}
      <LogViewer logs={logs} status={status} />
    </div>
  );
}
