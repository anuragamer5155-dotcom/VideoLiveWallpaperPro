import React, { useState, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Upload, FolderArchive, AlertCircle, CheckCircle2, Loader2 } from 'lucide-react';
import axios from 'axios';

const MAX_SIZE_MB = 500;
const ALLOWED_EXTS = ['.zip', '.tar.gz', '.tgz'];

const TYPE_ICONS = {
  gradle: { label: 'Gradle / Java / Kotlin', color: 'text-orange-400', dot: 'bg-orange-400' },
  flutter: { label: 'Flutter / Dart', color: 'text-blue-400', dot: 'bg-blue-400' },
  'react-native': { label: 'React Native', color: 'text-cyan-400', dot: 'bg-cyan-400' },
  unknown: { label: 'Unknown (will try Gradle)', color: 'text-slate-400', dot: 'bg-slate-400' },
};

function formatBytes(bytes) {
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export default function UploadZone({ onBuildStarted }) {
  const [dragging, setDragging] = useState(false);
  const [file, setFile] = useState(null);
  const [error, setError] = useState('');
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const inputRef = useRef(null);

  const validateFile = (f) => {
    const name = f.name.toLowerCase();
    const valid = ALLOWED_EXTS.some(ext => name.endsWith(ext));
    if (!valid) return `Invalid file type. Allowed: ${ALLOWED_EXTS.join(', ')}`;
    if (f.size > MAX_SIZE_MB * 1024 * 1024) return `File too large. Max ${MAX_SIZE_MB}MB.`;
    return null;
  };

  const handleFile = useCallback((f) => {
    setError('');
    const err = validateFile(f);
    if (err) { setError(err); setFile(null); return; }
    setFile(f);
  }, []);

  const onDrop = useCallback((e) => {
    e.preventDefault();
    setDragging(false);
    const f = e.dataTransfer.files[0];
    if (f) handleFile(f);
  }, [handleFile]);

  const onDragOver = (e) => { e.preventDefault(); setDragging(true); };
  const onDragLeave = () => setDragging(false);

  const handleSubmit = async () => {
    if (!file) return;
    setUploading(true);
    setError('');
    setUploadProgress(0);

    const formData = new FormData();
    formData.append('project', file);

    try {
      const res = await axios.post('/api/upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
        onUploadProgress: (e) => {
          setUploadProgress(Math.round((e.loaded / e.total) * 100));
        },
      });

      onBuildStarted({
        jobId: res.data.jobId,
        projectType: res.data.projectType,
        fileName: file.name,
      });
    } catch (err) {
      setError(err.response?.data?.error || 'Upload failed. Please try again.');
      setUploading(false);
    }
  };

  return (
    <div className="grid lg:grid-cols-5 gap-6 mb-10">
      {/* Drop Zone */}
      <div className="lg:col-span-3">
        <div
          onDrop={onDrop}
          onDragOver={onDragOver}
          onDragLeave={onDragLeave}
          onClick={() => !file && inputRef.current?.click()}
          className={`
            relative scanline rounded-lg border-2 border-dashed transition-all duration-300 cursor-pointer
            min-h-[280px] flex flex-col items-center justify-center p-8 text-center
            ${dragging
              ? 'border-acid-400 bg-acid-500/5 glow-acid'
              : file
              ? 'border-acid-500/50 bg-acid-500/5'
              : 'border-void-600 bg-void-800/50 hover:border-void-500 hover:bg-void-800'}
          `}
        >
          <input
            ref={inputRef}
            type="file"
            accept=".zip,.tar.gz,.tgz"
            className="hidden"
            onChange={(e) => e.target.files[0] && handleFile(e.target.files[0])}
          />

          <AnimatePresence mode="wait">
            {file ? (
              <motion.div
                key="file"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0 }}
                className="flex flex-col items-center gap-3"
              >
                <div className="w-14 h-14 rounded-xl bg-acid-500/10 border border-acid-500/30 flex items-center justify-center">
                  <CheckCircle2 className="w-7 h-7 text-acid-400" />
                </div>
                <div>
                  <p className="font-display font-bold text-white">{file.name}</p>
                  <p className="text-sm text-slate-500 mt-0.5">{formatBytes(file.size)}</p>
                </div>
                <button
                  onClick={(e) => { e.stopPropagation(); setFile(null); setError(''); }}
                  className="text-xs text-slate-500 hover:text-slate-300 underline mt-1"
                >
                  Remove
                </button>
              </motion.div>
            ) : (
              <motion.div
                key="empty"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex flex-col items-center gap-4"
              >
                <motion.div
                  animate={{ y: dragging ? -6 : 0 }}
                  transition={{ type: 'spring', stiffness: 300 }}
                  className="w-16 h-16 rounded-2xl bg-void-700 border border-void-600 flex items-center justify-center"
                >
                  <Upload className="w-7 h-7 text-slate-500" />
                </motion.div>
                <div>
                  <p className="font-display font-bold text-white text-lg">
                    {dragging ? 'Drop it here' : 'Drop your project archive'}
                  </p>
                  <p className="text-sm text-slate-500 mt-1">
                    or <span className="text-acid-400 underline">browse files</span>
                  </p>
                </div>
                <div className="flex gap-2 flex-wrap justify-center">
                  {ALLOWED_EXTS.map(ext => (
                    <span key={ext} className="px-2 py-0.5 text-xs font-mono bg-void-700 border border-void-600 rounded text-slate-400">
                      {ext}
                    </span>
                  ))}
                </div>
                <p className="text-xs text-slate-600">Max {MAX_SIZE_MB}MB</p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Error */}
        <AnimatePresence>
          {error && (
            <motion.div
              initial={{ opacity: 0, y: -6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="mt-3 flex items-center gap-2 text-red-400 text-sm bg-red-500/10 border border-red-500/20 rounded px-3 py-2"
            >
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              {error}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Upload progress */}
        <AnimatePresence>
          {uploading && (
            <motion.div
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="mt-3"
            >
              <div className="flex justify-between text-xs text-slate-500 mb-1">
                <span className="font-mono">Uploading...</span>
                <span className="font-mono">{uploadProgress}%</span>
              </div>
              <div className="h-1 bg-void-700 rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-acid-500 rounded-full"
                  initial={{ width: 0 }}
                  animate={{ width: `${uploadProgress}%` }}
                  transition={{ ease: 'easeOut' }}
                />
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Submit button */}
        <motion.button
          onClick={handleSubmit}
          disabled={!file || uploading}
          whileTap={{ scale: 0.97 }}
          className={`mt-4 w-full py-3 rounded font-display font-bold text-sm transition-all duration-200 flex items-center justify-center gap-2
            ${file && !uploading
              ? 'btn-acid cursor-pointer'
              : 'bg-void-700 text-slate-600 cursor-not-allowed border border-void-600'}
          `}
        >
          {uploading ? (
            <><Loader2 className="w-4 h-4 animate-spin" /> Uploading & Queuing...</>
          ) : (
            <><FolderArchive className="w-4 h-4" /> Start AI Build</>
          )}
        </motion.button>
      </div>

      {/* Info panel */}
      <div className="lg:col-span-2 space-y-4">
        {/* Supported types */}
        <div className="glass rounded-lg p-4">
          <h3 className="font-display text-xs font-bold text-slate-400 uppercase tracking-widest mb-3">
            Supported Project Types
          </h3>
          <div className="space-y-2.5">
            {Object.entries(TYPE_ICONS).filter(([k]) => k !== 'unknown').map(([type, meta]) => (
              <div key={type} className="flex items-center gap-2.5">
                <span className={`w-2 h-2 rounded-full flex-shrink-0 ${meta.dot}`} />
                <span className={`text-sm font-mono ${meta.color}`}>{meta.label}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Pipeline */}
        <div className="glass rounded-lg p-4">
          <h3 className="font-display text-xs font-bold text-slate-400 uppercase tracking-widest mb-3">
            Build Pipeline
          </h3>
          <ol className="space-y-2">
            {[
              ['01', 'Extract & analyze project'],
              ['02', 'Run build in Docker sandbox'],
              ['03', 'AI fixes errors automatically'],
              ['04', 'Retry build (up to 3×)'],
              ['05', 'Download APK'],
            ].map(([n, label]) => (
              <li key={n} className="flex items-start gap-2 text-sm text-slate-400">
                <span className="font-mono text-acid-500/70 text-xs mt-0.5 w-5 flex-shrink-0">{n}</span>
                {label}
              </li>
            ))}
          </ol>
        </div>

        {/* Tips */}
        <div className="glass rounded-lg p-4 border-l-2 border-plasma-400/50">
          <h3 className="font-display text-xs font-bold text-plasma-400 uppercase tracking-widest mb-2">
            Tips
          </h3>
          <ul className="space-y-1.5 text-xs text-slate-500">
            <li>• Export from Replit as ZIP</li>
            <li>• Include <code className="text-slate-400">gradle/</code> folder</li>
            <li>• Root of ZIP = project root</li>
            <li>• No need for local.properties</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
