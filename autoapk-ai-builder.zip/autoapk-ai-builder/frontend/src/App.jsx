import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Header from './components/Header.jsx';
import UploadZone from './components/UploadZone.jsx';
import BuildDashboard from './components/BuildDashboard.jsx';
import QueueStatus from './components/QueueStatus.jsx';

export default function App() {
  const [activeBuild, setActiveBuild] = useState(null);

  return (
    <div className="min-h-screen grid-bg text-slate-200">
      {/* Ambient glow orbs */}
      <div className="fixed top-0 left-1/4 w-96 h-96 bg-acid-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="fixed bottom-1/4 right-1/4 w-64 h-64 bg-plasma-500/5 rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10 max-w-6xl mx-auto px-4 py-8">
        <Header />

        <AnimatePresence mode="wait">
          {!activeBuild ? (
            <motion.div
              key="upload"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.35 }}
            >
              <UploadZone onBuildStarted={setActiveBuild} />
              <QueueStatus />
            </motion.div>
          ) : (
            <motion.div
              key="dashboard"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.35 }}
            >
              <BuildDashboard
                jobId={activeBuild.jobId}
                projectType={activeBuild.projectType}
                fileName={activeBuild.fileName}
                onReset={() => setActiveBuild(null)}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
