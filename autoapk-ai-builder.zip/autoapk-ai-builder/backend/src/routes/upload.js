import express from 'express';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';
import fs from 'fs-extra';
import { logger } from '../utils/logger.js';
import { addBuildJob } from '../queue/buildQueue.js';
import { extractArchive } from '../services/extractor.js';
import { detectProjectType } from '../services/detector.js';

const router = express.Router();

const ALLOWED_EXTENSIONS = ['.zip', '.tar.gz', '.tgz', '.gz'];

function getExtension(filename) {
  if (filename.endsWith('.tar.gz')) return '.tar.gz';
  return path.extname(filename).toLowerCase();
}

router.post('/', async (req, res) => {
  try {
    if (!req.files || !req.files.project) {
      return res.status(400).json({ error: 'No project file uploaded.' });
    }

    const file = req.files.project;
    const ext = getExtension(file.name);

    if (!ALLOWED_EXTENSIONS.includes(ext)) {
      return res.status(400).json({
        error: `Invalid file type. Allowed: ${ALLOWED_EXTENSIONS.join(', ')}`,
      });
    }

    const jobId = uuidv4();
    const uploadPath = path.join(process.env.UPLOAD_DIR || '/app/uploads', `${jobId}${ext}`);
    const workspacePath = path.join('/app/workspaces', jobId);

    await fs.ensureDir(workspacePath);
    await file.mv(uploadPath);

    logger.info(`File uploaded: ${file.name} → ${uploadPath} [job: ${jobId}]`);

    // Extract immediately for project type detection
    await extractArchive(uploadPath, workspacePath);
    const projectType = await detectProjectType(workspacePath);

    // Queue the build job
    const job = await addBuildJob({
      jobId,
      uploadPath,
      workspacePath,
      originalName: file.name,
      projectType,
    });

    logger.info(`Build job queued: ${jobId} (type: ${projectType})`);

    res.json({
      jobId,
      projectType,
      message: 'Project uploaded and queued for build.',
      queuePosition: await job.getPosition(),
    });
  } catch (err) {
    logger.error('Upload error:', err);
    res.status(500).json({ error: err.message });
  }
});

export default router;
