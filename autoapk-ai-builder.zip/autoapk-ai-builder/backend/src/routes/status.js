import express from 'express';
import { getQueueStats } from '../queue/buildQueue.js';

const router = express.Router();

router.get('/queue', async (req, res) => {
  try {
    const stats = await getQueueStats();
    res.json(stats);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
