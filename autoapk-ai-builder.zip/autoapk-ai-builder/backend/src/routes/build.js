import express from 'express';
import path from 'path';
import fs from 'fs-extra';
import { getBuildJob } from '../queue/buildQueue.js';
import { logger } from '../utils/logger.js';

const router = express.Router();

// Get build status
router.get('/:jobId', async (req, res) => {
  try {
    const { jobId } = req.params;
    const job = await getBuildJob(jobId);

    if (!job) {
      return res.status(404).json({ error: 'Build job not found.' });
    }

    const state = await job.getState();
    const progress = job.progress;
    const returnValue = job.returnvalue;
    const failedReason = job.failedReason;

    res.json({
      jobId,
      state,
      progress,
      returnValue,
      failedReason,
      data: job.data,
    });
  } catch (err) {
    logger.error('Status error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Download APK
router.get('/:jobId/download', async (req, res) => {
  try {
    const { jobId } = req.params;
    const outputDir = process.env.OUTPUT_DIR || '/app/outputs';
    const apkPath = path.join(outputDir, jobId, 'app.apk');

    if (!await fs.pathExists(apkPath)) {
      return res.status(404).json({ error: 'APK not found or build not complete.' });
    }

    res.download(apkPath, `app-${jobId.slice(0, 8)}.apk`);
  } catch (err) {
    logger.error('Download error:', err);
    res.status(500).json({ error: err.message });
  }
});

export default router;
