import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import fileUpload from 'express-fileupload';
import rateLimit from 'express-rate-limit';
import { createServer } from 'http';
import { Server as SocketIO } from 'socket.io';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs-extra';

import uploadRouter from './routes/upload.js';
import buildRouter from './routes/build.js';
import statusRouter from './routes/status.js';
import { initWorker } from './workers/buildWorker.js';
import { logger } from './utils/logger.js';
import { registerSocketHandlers } from './services/socketService.js';

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const httpServer = createServer(app);

// Socket.IO for live logs
export const io = new SocketIO(httpServer, {
  cors: {
    origin: process.env.FRONTEND_URL || '*',
    methods: ['GET', 'POST'],
  },
});

// Ensure directories exist
await fs.ensureDir(process.env.UPLOAD_DIR || '/app/uploads');
await fs.ensureDir(process.env.OUTPUT_DIR || '/app/outputs');
await fs.ensureDir('/app/workspaces');

// Security middleware
app.use(helmet({ crossOriginEmbedderPolicy: false }));
app.use(cors({
  origin: process.env.FRONTEND_URL || '*',
  methods: ['GET', 'POST', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 20,
  message: { error: 'Too many requests. Please wait.' },
});
app.use('/api/', limiter);

// Body parsing
app.use(express.json({ limit: '10mb' }));

// File upload middleware
const maxSizeMB = parseInt(process.env.MAX_FILE_SIZE_MB || '500');
app.use(fileUpload({
  limits: { fileSize: maxSizeMB * 1024 * 1024 },
  useTempFiles: true,
  tempFileDir: '/tmp/',
  abortOnLimit: true,
  uploadTimeout: 60000,
  safeFileNames: true,
  preserveExtension: true,
}));

// Static file serving for APKs
app.use('/downloads', express.static(process.env.OUTPUT_DIR || '/app/outputs'));

// API Routes
app.use('/api/upload', uploadRouter);
app.use('/api/build', buildRouter);
app.use('/api/status', statusRouter);

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Not found' });
});

// Error handler
app.use((err, req, res, next) => {
  logger.error('Unhandled error:', err);
  res.status(500).json({ error: err.message || 'Internal server error' });
});

// Socket.IO handlers
registerSocketHandlers(io);

// Start worker
await initWorker(io);

const PORT = process.env.PORT || 3001;
httpServer.listen(PORT, () => {
  logger.info(`🚀 AutoAPK Backend running on port ${PORT}`);
});

export default app;
