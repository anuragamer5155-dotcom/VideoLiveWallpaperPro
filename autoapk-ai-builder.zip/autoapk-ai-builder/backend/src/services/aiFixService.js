import OpenAI from 'openai';
import path from 'path';
import fs from 'fs-extra';
import { glob } from 'glob';
import { logger } from '../utils/logger.js';

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const SYSTEM_PROMPT = `You are an expert Android build engineer specializing in fixing Gradle, Flutter, and React Native build failures.

Given build logs and project files, you must:
1. Identify the ROOT CAUSE of the build failure
2. Provide SPECIFIC file changes to fix it
3. Return ONLY valid JSON, no markdown

Response format:
{
  "analysis": "Brief description of root cause",
  "fixes": [
    {
      "type": "modify_file" | "create_file" | "delete_file",
      "path": "relative/path/from/workspace",
      "content": "full new file content (for modify/create)",
      "description": "what this fix does"
    }
  ],
  "explanation": "What was wrong and what you fixed"
}

Common fixes you know:
- Add missing dependencies to build.gradle
- Fix SDK version mismatches (compileSdkVersion, targetSdkVersion, minSdkVersion)
- Add missing repositories (google(), mavenCentral(), jcenter())
- Fix Java compatibility (sourceCompatibility, targetCompatibility JavaVersion.VERSION_17)
- Create missing local.properties with sdk.dir=/opt/android-sdk
- Fix Kotlin version mismatches
- Fix Flutter pubspec.yaml dependency conflicts
- Add missing permissions in AndroidManifest.xml
- Fix NDK issues
- Fix missing signing config for debug builds
- Fix Gradle wrapper version issues
- Fix React Native metro.config.js issues`;

export async function aiFixErrors({ jobId, workspacePath, projectType, buildLogs, attempt, onLog }) {
  if (!process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY === 'sk-your-openai-key-here') {
    onLog('⚠️  OpenAI API key not configured. Applying default fixes...');
    return await applyDefaultFixes(workspacePath, projectType, buildLogs, onLog);
  }

  onLog('🤖 Analyzing build logs with AI...');

  // Gather relevant project files
  const projectFiles = await gatherProjectFiles(workspacePath, projectType);

  const userMessage = `
PROJECT TYPE: ${projectType}
BUILD ATTEMPT: ${attempt}

RELEVANT PROJECT FILES:
${projectFiles}

BUILD LOGS (last 4000 chars):
${buildLogs.slice(-4000)}

Analyze the failure and provide fixes as JSON.`;

  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-4o',
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        { role: 'user', content: userMessage },
      ],
      temperature: 0.1,
      max_tokens: 4000,
      response_format: { type: 'json_object' },
    });

    const result = JSON.parse(response.choices[0].message.content);

    onLog(`🤖 AI Analysis: ${result.analysis}`);
    onLog(`🤖 Explanation: ${result.explanation}`);

    if (!result.fixes || result.fixes.length === 0) {
      onLog('🤖 AI found no applicable fixes.');
      return [];
    }

    const applied = await applyFixes(workspacePath, result.fixes, onLog);
    return applied;

  } catch (err) {
    logger.error(`AI fix error for job ${jobId}:`, err);
    onLog(`⚠️  AI error: ${err.message}. Applying heuristic fixes...`);
    return await applyDefaultFixes(workspacePath, projectType, buildLogs, onLog);
  }
}

async function applyFixes(workspacePath, fixes, onLog) {
  const applied = [];

  for (const fix of fixes) {
    try {
      const fullPath = path.join(workspacePath, fix.path);

      // Security: ensure path stays within workspace
      if (!fullPath.startsWith(workspacePath)) {
        onLog(`⚠️  Skipping unsafe fix path: ${fix.path}`);
        continue;
      }

      if (fix.type === 'modify_file' || fix.type === 'create_file') {
        await fs.ensureDir(path.dirname(fullPath));
        await fs.writeFile(fullPath, fix.content, 'utf-8');
        onLog(`✏️  ${fix.type === 'create_file' ? 'Created' : 'Modified'}: ${fix.path}`);
        onLog(`   → ${fix.description}`);
        applied.push(fix);
      } else if (fix.type === 'delete_file') {
        if (await fs.pathExists(fullPath)) {
          await fs.remove(fullPath);
          onLog(`🗑️  Deleted: ${fix.path}`);
          applied.push(fix);
        }
      }
    } catch (err) {
      onLog(`⚠️  Failed to apply fix for ${fix.path}: ${err.message}`);
    }
  }

  return applied;
}

async function applyDefaultFixes(workspacePath, projectType, buildLogs, onLog) {
  const fixes = [];

  // Fix 1: Always ensure local.properties exists
  const localProps = path.join(workspacePath, 'local.properties');
  if (!await fs.pathExists(localProps)) {
    await fs.writeFile(localProps, 'sdk.dir=/opt/android-sdk\n', 'utf-8');
    onLog('🔧 Created local.properties with sdk.dir');
    fixes.push({ path: 'local.properties' });
  }

  // Fix 2: Make gradlew executable
  const gradlew = path.join(workspacePath, 'gradlew');
  if (await fs.pathExists(gradlew)) {
    await fs.chmod(gradlew, 0o755);
    onLog('🔧 Made gradlew executable');
    fixes.push({ path: 'gradlew' });
  }

  // Fix 3: Fix compileSdkVersion issues
  if (buildLogs.includes('compileSdk') || buildLogs.includes('Minimum supported Gradle')) {
    const appBuildGradle = path.join(workspacePath, 'app/build.gradle');
    if (await fs.pathExists(appBuildGradle)) {
      let content = await fs.readFile(appBuildGradle, 'utf-8');
      let changed = false;

      // Fix old compileSdkVersion to compileSdk
      if (content.includes('compileSdkVersion 3') || content.includes('compileSdkVersion 2')) {
        content = content.replace(/compileSdkVersion\s+\d+/, 'compileSdk 34');
        changed = true;
      }
      if (content.includes('targetSdkVersion 2') || content.includes('targetSdkVersion 3')) {
        content = content.replace(/targetSdkVersion\s+\d+/, 'targetSdk 34');
        changed = true;
      }

      if (changed) {
        await fs.writeFile(appBuildGradle, content, 'utf-8');
        onLog('🔧 Updated SDK versions in app/build.gradle');
        fixes.push({ path: 'app/build.gradle' });
      }
    }
  }

  // Fix 4: Add google() repository if missing
  if (buildLogs.includes('Could not find') || buildLogs.includes('Failed to resolve')) {
    const buildGradle = path.join(workspacePath, 'build.gradle');
    if (await fs.pathExists(buildGradle)) {
      let content = await fs.readFile(buildGradle, 'utf-8');
      if (!content.includes('google()') && content.includes('repositories')) {
        content = content.replace(
          /repositories\s*\{/g,
          'repositories {\n        google()\n        mavenCentral()'
        );
        await fs.writeFile(buildGradle, content, 'utf-8');
        onLog('🔧 Added google() and mavenCentral() repositories');
        fixes.push({ path: 'build.gradle' });
      }
    }
  }

  // Fix 5: Gradle wrapper version
  if (buildLogs.includes('Could not find org.gradle') || buildLogs.includes('Unsupported class file major version')) {
    const wrapperProps = path.join(workspacePath, 'gradle/wrapper/gradle-wrapper.properties');
    if (await fs.pathExists(wrapperProps)) {
      let content = await fs.readFile(wrapperProps, 'utf-8');
      content = content.replace(
        /distributionUrl=.*/,
        'distributionUrl=https\\://services.gradle.org/distributions/gradle-8.4-bin.zip'
      );
      await fs.writeFile(wrapperProps, content, 'utf-8');
      onLog('🔧 Updated Gradle wrapper to 8.4');
      fixes.push({ path: 'gradle/wrapper/gradle-wrapper.properties' });
    }
  }

  return fixes;
}

async function gatherProjectFiles(workspacePath, projectType) {
  const relevantFiles = {
    gradle: ['build.gradle', 'app/build.gradle', 'build.gradle.kts', 'app/build.gradle.kts',
              'settings.gradle', 'settings.gradle.kts', 'gradle/wrapper/gradle-wrapper.properties',
              'AndroidManifest.xml', 'app/src/main/AndroidManifest.xml'],
    flutter: ['pubspec.yaml', 'android/build.gradle', 'android/app/build.gradle',
               'android/local.properties'],
    'react-native': ['package.json', 'android/build.gradle', 'android/app/build.gradle',
                      'android/gradle/wrapper/gradle-wrapper.properties'],
  };

  const files = relevantFiles[projectType] || relevantFiles.gradle;
  let result = '';

  for (const relPath of files) {
    const fullPath = path.join(workspacePath, relPath);
    if (await fs.pathExists(fullPath)) {
      try {
        const content = await fs.readFile(fullPath, 'utf-8');
        result += `\n=== ${relPath} ===\n${content.slice(0, 2000)}\n`;
      } catch (_) {}
    }
  }

  return result || 'No relevant files found';
}
