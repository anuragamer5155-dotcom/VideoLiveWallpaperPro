import { logger } from '../utils/logger.js';

export function registerSocketHandlers(io) {
  io.on('connection', (socket) => {
    logger.info(`Client connected: ${socket.id}`);

    socket.on('subscribe', (jobId) => {
      if (typeof jobId === 'string' && jobId.length < 100) {
        socket.join(`job:${jobId}`);
        logger.info(`Client ${socket.id} subscribed to job: ${jobId}`);
        socket.emit('subscribed', { jobId });
      }
    });

    socket.on('unsubscribe', (jobId) => {
      socket.leave(`job:${jobId}`);
    });

    socket.on('disconnect', () => {
      logger.info(`Client disconnected: ${socket.id}`);
    });
  });
}
