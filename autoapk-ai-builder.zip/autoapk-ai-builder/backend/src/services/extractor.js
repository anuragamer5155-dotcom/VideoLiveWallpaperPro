import AdmZip from 'adm-zip';
import tar from 'tar';
import path from 'path';
import fs from 'fs-extra';
import { logger } from '../utils/logger.js';

// Security: check for path traversal attacks
function isSafePath(entryPath, destDir) {
  const resolved = path.resolve(destDir, entryPath);
  return resolved.startsWith(path.resolve(destDir));
}

export async function extractArchive(archivePath, destDir) {
  await fs.ensureDir(destDir);
  const ext = archivePath.endsWith('.tar.gz') ? '.tar.gz'
    : archivePath.endsWith('.tgz') ? '.tgz'
    : path.extname(archivePath).toLowerCase();

  logger.info(`Extracting ${ext} archive: ${archivePath} → ${destDir}`);

  if (ext === '.zip') {
    await extractZip(archivePath, destDir);
  } else if (['.tar.gz', '.tgz', '.gz'].includes(ext)) {
    await extractTar(archivePath, destDir);
  } else {
    throw new Error(`Unsupported archive format: ${ext}`);
  }

  // Flatten single top-level directory (common in GitHub/Replit exports)
  await flattenSingleDir(destDir);

  logger.info(`Extraction complete: ${destDir}`);
}

async function extractZip(archivePath, destDir) {
  const zip = new AdmZip(archivePath);
  const entries = zip.getEntries();

  for (const entry of entries) {
    const entryPath = entry.entryName;

    // Security: skip dangerous paths
    if (entryPath.includes('..') || path.isAbsolute(entryPath)) {
      logger.warn(`Skipping unsafe zip entry: ${entryPath}`);
      continue;
    }

    if (!isSafePath(entryPath, destDir)) {
      logger.warn(`Skipping path traversal attempt: ${entryPath}`);
      continue;
    }

    const fullPath = path.join(destDir, entryPath);

    if (entry.isDirectory) {
      await fs.ensureDir(fullPath);
    } else {
      await fs.ensureDir(path.dirname(fullPath));
      await fs.writeFile(fullPath, entry.getData());
    }
  }
}

async function extractTar(archivePath, destDir) {
  await tar.extract({
    file: archivePath,
    cwd: destDir,
    filter: (filePath) => {
      // Security: filter dangerous paths
      const normalized = path.normalize(filePath);
      return !normalized.startsWith('..') && !path.isAbsolute(normalized);
    },
    strict: false,
  });
}

async function flattenSingleDir(dir) {
  const entries = await fs.readdir(dir);

  // Filter out hidden files
  const visible = entries.filter(e => !e.startsWith('.'));

  if (visible.length === 1) {
    const subDir = path.join(dir, visible[0]);
    const stat = await fs.stat(subDir);

    if (stat.isDirectory()) {
      logger.info(`Flattening single top-level directory: ${visible[0]}`);
      const subEntries = await fs.readdir(subDir);

      for (const entry of subEntries) {
        await fs.move(
          path.join(subDir, entry),
          path.join(dir, entry),
          { overwrite: true }
        );
      }

      await fs.remove(subDir);
    }
  }
}
