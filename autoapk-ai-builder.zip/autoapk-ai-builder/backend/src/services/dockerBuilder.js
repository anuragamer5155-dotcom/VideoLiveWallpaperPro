import Docker from 'dockerode';
import path from 'path';
import { logger } from '../utils/logger.js';

const docker = new Docker({ socketPath: '/var/run/docker.sock' });

const BUILD_COMMANDS = {
  gradle: [
    'bash', '-c',
    `
    set -e
    cd /workspace

    # Make gradlew executable
    chmod +x gradlew 2>/dev/null || true

    # Set Android SDK location
    export ANDROID_HOME=/opt/android-sdk
    export ANDROID_SDK_ROOT=/opt/android-sdk
    export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools

    # Accept licenses
    yes | sdkmanager --licenses 2>/dev/null || true

    # Try wrapper first, fallback to system gradle
    if [ -f "./gradlew" ]; then
      echo ">>> Using Gradle wrapper"
      ./gradlew assembleDebug --stacktrace --no-daemon 2>&1
    else
      echo ">>> Using system Gradle"
      gradle assembleDebug --stacktrace --no-daemon 2>&1
    fi
    `
  ],
  flutter: [
    'bash', '-c',
    `
    set -e
    cd /workspace
    export ANDROID_HOME=/opt/android-sdk
    export ANDROID_SDK_ROOT=/opt/android-sdk
    export PATH=$PATH:/opt/flutter/bin:$ANDROID_HOME/platform-tools

    echo ">>> Running flutter pub get"
    flutter pub get 2>&1

    echo ">>> Building Flutter APK"
    flutter build apk --debug --no-tree-shake-icons 2>&1
    `
  ],
  'react-native': [
    'bash', '-c',
    `
    set -e
    cd /workspace
    export ANDROID_HOME=/opt/android-sdk
    export ANDROID_SDK_ROOT=/opt/android-sdk
    export PATH=$PATH:$ANDROID_HOME/platform-tools

    echo ">>> Installing npm dependencies"
    npm install --legacy-peer-deps 2>&1

    echo ">>> Building React Native APK"
    cd android && chmod +x gradlew && ./gradlew assembleDebug --no-daemon 2>&1
    `
  ],
};

export async function runDockerBuild({ jobId, workspacePath, projectType, onLog }) {
  const image = process.env.DOCKER_BUILDER_IMAGE || 'autoapk-builder:latest';
  const timeout = parseInt(process.env.BUILD_TIMEOUT_SECONDS || '600') * 1000;

  onLog(`🐳 Starting Docker container (image: ${image})`);

  let container;
  let logs = '';

  try {
    container = await docker.createContainer({
      Image: image,
      Cmd: BUILD_COMMANDS[projectType] || BUILD_COMMANDS.gradle,
      HostConfig: {
        Binds: [`${workspacePath}:/workspace:rw`],
        Memory: 4 * 1024 * 1024 * 1024, // 4GB RAM limit
        CpuShares: 1024,
        NetworkMode: 'none', // No network during build for security
        AutoRemove: false,
        SecurityOpt: ['no-new-privileges'],
        ReadonlyRootfs: false,
        Tmpfs: { '/tmp': 'rw,noexec,nosuid,size=512m' },
      },
      Env: [
        `ANDROID_HOME=/opt/android-sdk`,
        `ANDROID_SDK_ROOT=/opt/android-sdk`,
        `JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64`,
        `GRADLE_OPTS=-Xmx2g -Dorg.gradle.daemon=false`,
      ],
      WorkingDir: '/workspace',
      AttachStdout: true,
      AttachStderr: true,
    });

    await container.start();
    onLog(`🐳 Container started: ${container.id.slice(0, 12)}`);

    // Stream logs
    const stream = await container.logs({
      follow: true,
      stdout: true,
      stderr: true,
    });

    await new Promise((resolve, reject) => {
      const timeoutId = setTimeout(() => {
        container.stop().catch(() => {});
        reject(new Error(`Build timed out after ${timeout / 1000}s`));
      }, timeout);

      container.modem.demuxStream(stream, {
        write: (chunk) => {
          const line = chunk.toString('utf-8').trim();
          if (line) {
            logs += line + '\n';
            onLog(line);
          }
        }
      }, {
        write: (chunk) => {
          const line = chunk.toString('utf-8').trim();
          if (line) {
            logs += line + '\n';
            onLog(`[STDERR] ${line}`);
          }
        }
      });

      stream.on('end', () => {
        clearTimeout(timeoutId);
        resolve();
      });

      stream.on('error', (err) => {
        clearTimeout(timeoutId);
        reject(err);
      });
    });

    // Get exit code
    const info = await container.inspect();
    const exitCode = info.State.ExitCode;

    onLog(`🐳 Container exited with code: ${exitCode}`);

    return {
      success: exitCode === 0,
      exitCode,
      logs,
    };

  } catch (err) {
    logger.error(`Docker build error for job ${jobId}:`, err);
    return {
      success: false,
      exitCode: -1,
      logs: logs + '\nDocker error: ' + err.message,
    };
  } finally {
    if (container) {
      await container.remove({ force: true }).catch(() => {});
    }
  }
}
