import path from 'path';
import fs from 'fs-extra';
import { glob } from 'glob';
import { logger } from '../utils/logger.js';

export const PROJECT_TYPES = {
  GRADLE: 'gradle',
  FLUTTER: 'flutter',
  REACT_NATIVE: 'react-native',
  UNKNOWN: 'unknown',
};

export async function detectProjectType(workspacePath) {
  logger.info(`Detecting project type in: ${workspacePath}`);

  // Flutter: pubspec.yaml with flutter dependency
  const pubspecPath = path.join(workspacePath, 'pubspec.yaml');
  if (await fs.pathExists(pubspecPath)) {
    const content = await fs.readFile(pubspecPath, 'utf-8');
    if (content.includes('flutter:') || content.includes('flutter_test:')) {
      logger.info('Detected: Flutter project');
      return PROJECT_TYPES.FLUTTER;
    }
  }

  // React Native: package.json with react-native
  const packageJsonPath = path.join(workspacePath, 'package.json');
  if (await fs.pathExists(packageJsonPath)) {
    try {
      const pkg = await fs.readJson(packageJsonPath);
      const deps = { ...pkg.dependencies, ...pkg.devDependencies };
      if (deps['react-native'] || deps['@react-native-community/cli']) {
        logger.info('Detected: React Native project');
        return PROJECT_TYPES.REACT_NATIVE;
      }
    } catch (_) {}
  }

  // Gradle: build.gradle or build.gradle.kts
  const gradleFiles = await glob('**/build.gradle{,.kts}', {
    cwd: workspacePath,
    ignore: ['**/node_modules/**', '**/.gradle/**'],
    maxDepth: 4,
  });

  if (gradleFiles.length > 0) {
    // Check it's an Android project
    for (const gf of gradleFiles) {
      const content = await fs.readFile(path.join(workspacePath, gf), 'utf-8');
      if (content.includes('android') || content.includes('com.android')) {
        logger.info('Detected: Gradle/Android project');
        return PROJECT_TYPES.GRADLE;
      }
    }
  }

  // Fallback: look for AndroidManifest.xml
  const manifests = await glob('**/AndroidManifest.xml', {
    cwd: workspacePath,
    ignore: ['**/node_modules/**'],
    maxDepth: 6,
  });

  if (manifests.length > 0) {
    logger.info('Detected: Android project (by manifest)');
    return PROJECT_TYPES.GRADLE;
  }

  logger.warn('Could not detect project type');
  return PROJECT_TYPES.UNKNOWN;
}
