import { glob } from 'glob';
import { logger } from '../utils/logger.js';

export async function findApkFile(workspacePath) {
  logger.info(`Searching for APK in: ${workspacePath}`);

  // Common APK output locations by project type
  const patterns = [
    // Gradle/Android
    '**/app/build/outputs/apk/debug/*.apk',
    '**/app/build/outputs/apk/release/*.apk',
    '**/build/outputs/apk/debug/*.apk',
    '**/build/outputs/apk/release/*.apk',
    // Flutter
    '**/build/app/outputs/flutter-apk/*.apk',
    '**/build/app/outputs/apk/debug/*.apk',
    // React Native
    '**/android/app/build/outputs/apk/debug/*.apk',
    '**/android/app/build/outputs/apk/release/*.apk',
    // Generic fallback
    '**/*.apk',
  ];

  for (const pattern of patterns) {
    const matches = await glob(pattern, {
      cwd: workspacePath,
      absolute: true,
      ignore: ['**/node_modules/**', '**/.gradle/**'],
    });

    if (matches.length > 0) {
      // Prefer debug over release, prefer smaller patterns (more specific)
      const sorted = matches.sort((a, b) => {
        if (a.includes('debug') && !b.includes('debug')) return -1;
        if (!a.includes('debug') && b.includes('debug')) return 1;
        return 0;
      });

      logger.info(`Found APK: ${sorted[0]}`);
      return sorted[0];
    }
  }

  logger.warn('No APK file found');
  return null;
}
