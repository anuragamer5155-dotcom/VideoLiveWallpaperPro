import { Worker } from 'bullmq';
import path from 'path';
import fs from 'fs-extra';
import { logger } from '../utils/logger.js';
import { runDockerBuild } from '../services/dockerBuilder.js';
import { aiFixErrors } from '../services/aiFixService.js';
import { findApkFile } from '../services/apkFinder.js';

const connection = {
  host: process.env.REDIS_HOST || 'redis',
  port: parseInt(process.env.REDIS_PORT || '6379'),
};

const STEPS = {
  EXTRACT:   { id: 'extract',   label: 'Extracting Files',        pct: 10 },
  ANALYZE:   { id: 'analyze',   label: 'Analyzing Project',       pct: 20 },
  BUILD:     { id: 'build',     label: 'Building APK',            pct: 50 },
  FIX:       { id: 'fix',       label: 'AI Fixing Errors',        pct: 70 },
  PACKAGE:   { id: 'package',   label: 'Packaging Output',        pct: 90 },
  DONE:      { id: 'done',      label: 'Build Complete',          pct: 100 },
};

export async function initWorker(io) {
  const worker = new Worker(
    'apk-builds',
    async (job) => {
      const { jobId, workspacePath, projectType } = job.data;
      const emit = (event, data) => io.to(`job:${jobId}`).emit(event, data);

      function log(msg, level = 'info') {
        const entry = { ts: new Date().toISOString(), msg, level };
        logger[level](`[${jobId}] ${msg}`);
        emit('log', entry);
      }

      function setStep(step) {
        emit('step', step);
        job.updateProgress(step.pct);
      }

      try {
        log(`🚀 Starting build for job ${jobId} (type: ${projectType})`);

        // Step: Analyze
        setStep(STEPS.ANALYZE);
        log(`📂 Project type detected: ${projectType}`);
        log(`📁 Workspace: ${workspacePath}`);

        // Step: Build with retry loop
        const maxRetries = parseInt(process.env.MAX_RETRIES || '3');
        let buildSuccess = false;
        let lastLogs = '';
        let attempt = 0;

        while (attempt < maxRetries && !buildSuccess) {
          attempt++;
          setStep({ ...STEPS.BUILD, label: `Building APK (attempt ${attempt}/${maxRetries})`, pct: 30 + attempt * 10 });
          log(`🔨 Build attempt ${attempt}/${maxRetries}`);

          const result = await runDockerBuild({
            jobId,
            workspacePath,
            projectType,
            onLog: (line) => log(line),
          });

          lastLogs = result.logs;

          if (result.success) {
            buildSuccess = true;
            log('✅ Build succeeded!');
          } else {
            log(`❌ Build failed (attempt ${attempt}). Exit code: ${result.exitCode}`, 'warn');

            if (attempt < maxRetries) {
              setStep({ ...STEPS.FIX, label: `AI Fixing Errors (attempt ${attempt})`, pct: 65 });
              log('🤖 Invoking AI to analyze and fix build errors...');

              try {
                const fixes = await aiFixErrors({
                  jobId,
                  workspacePath,
                  projectType,
                  buildLogs: lastLogs,
                  attempt,
                  onLog: (line) => log(line),
                });

                if (fixes.length === 0) {
                  log('⚠️  AI found no fixable errors. Stopping retries.', 'warn');
                  break;
                }

                log(`🔧 AI applied ${fixes.length} fix(es). Retrying build...`);
              } catch (aiErr) {
                log(`⚠️  AI fix error: ${aiErr.message}. Retrying anyway.`, 'warn');
              }
            }
          }
        }

        if (!buildSuccess) {
          throw new Error(`Build failed after ${attempt} attempt(s).\n\nLast build output:\n${lastLogs.slice(-3000)}`);
        }

        // Step: Find and move APK
        setStep(STEPS.PACKAGE);
        log('📦 Locating APK file...');

        const apkSource = await findApkFile(workspacePath);
        if (!apkSource) {
          throw new Error('Build succeeded but no APK file found in output.');
        }

        const outputDir = path.join(process.env.OUTPUT_DIR || '/app/outputs', jobId);
        await fs.ensureDir(outputDir);
        const apkDest = path.join(outputDir, 'app.apk');
        await fs.copy(apkSource, apkDest);

        const stats = await fs.stat(apkDest);
        const sizeMB = (stats.size / (1024 * 1024)).toFixed(2);
        log(`✅ APK ready: ${sizeMB} MB`);

        // Cleanup workspace to free disk
        await fs.remove(workspacePath).catch(() => {});

        setStep(STEPS.DONE);
        emit('complete', {
          jobId,
          downloadUrl: `/downloads/${jobId}/app.apk`,
          sizeMB,
        });

        return { success: true, downloadUrl: `/downloads/${jobId}/app.apk`, sizeMB };

      } catch (err) {
        logger.error(`Job ${jobId} failed:`, err);
        emit('error', { message: err.message });
        throw err;
      }
    },
    {
      connection,
      concurrency: 2,
      stalledInterval: 30000,
      maxStalledCount: 1,
    }
  );

  worker.on('active', (job) => logger.info(`Worker: job ${job.id} started`));
  worker.on('completed', (job) => logger.info(`Worker: job ${job.id} completed`));
  worker.on('failed', (job, err) => logger.error(`Worker: job ${job?.id} failed:`, err.message));

  logger.info('✅ Build worker initialized');
  return worker;
}
