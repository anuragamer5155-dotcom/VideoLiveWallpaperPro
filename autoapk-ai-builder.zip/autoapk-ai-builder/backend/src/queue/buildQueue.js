import { Queue, QueueEvents } from 'bullmq';
import { logger } from '../utils/logger.js';

const connection = {
  host: process.env.REDIS_HOST || 'redis',
  port: parseInt(process.env.REDIS_PORT || '6379'),
};

export const buildQueue = new Queue('apk-builds', {
  connection,
  defaultJobOptions: {
    attempts: 1, // We handle retries manually via AI fixer
    removeOnComplete: { count: 50 },
    removeOnFail: { count: 50 },
    timeout: parseInt(process.env.BUILD_TIMEOUT_SECONDS || '600') * 1000,
  },
});

export const queueEvents = new QueueEvents('apk-builds', { connection });

export async function addBuildJob(data) {
  const job = await buildQueue.add('build-apk', data, {
    jobId: data.jobId,
    priority: 1,
  });
  logger.info(`Job ${data.jobId} added to queue`);
  return job;
}

export async function getBuildJob(jobId) {
  return await buildQueue.getJob(jobId);
}

export async function getQueueStats() {
  const [waiting, active, completed, failed, delayed] = await Promise.all([
    buildQueue.getWaitingCount(),
    buildQueue.getActiveCount(),
    buildQueue.getCompletedCount(),
    buildQueue.getFailedCount(),
    buildQueue.getDelayedCount(),
  ]);
  return { waiting, active, completed, failed, delayed };
}
