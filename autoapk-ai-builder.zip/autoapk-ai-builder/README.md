# AutoAPK AI Builder

Upload Android project archives and automatically build APKs — with AI-powered error fixing, live build logs, and one-click download.

---

## Architecture

```
┌─────────────┐     ┌──────────────┐     ┌──────────┐
│   Browser   │────▶│   Frontend   │────▶│  Nginx   │
│   (React)   │◀────│  (React+Vite)│◀────│  :80     │
└─────────────┘     └──────────────┘     └──────────┘
                                                │
                              ┌─────────────────┘
                              ▼
                    ┌──────────────────┐
                    │  Backend (Node)  │◀── WebSocket (Socket.IO)
                    │  Express + BullMQ│
                    └─────────┬────────┘
                              │
              ┌───────────────┼───────────────┐
              ▼               ▼               ▼
         ┌────────┐   ┌──────────────┐  ┌──────────┐
         │ Redis  │   │ Docker Build │  │ OpenAI   │
         │(queue) │   │  Container   │  │  API     │
         └────────┘   │(Android SDK) │  └──────────┘
                      └──────────────┘
```

### Services
| Service    | Description                              |
|------------|------------------------------------------|
| `frontend` | React + Tailwind served by Nginx on :80  |
| `backend`  | Node.js API + BullMQ worker on :3001     |
| `redis`    | Build job queue (BullMQ)                 |
| `builder`  | Docker image with Android SDK + Flutter  |

---

## Quick Start (Ubuntu Server)

### Prerequisites
- Ubuntu 22.04+ server (4+ CPU cores, 8+ GB RAM, 40+ GB disk)
- Open port 80 (and optionally 443 for HTTPS)

### 1. Clone the repo
```bash
git clone https://github.com/your-org/autoapk-ai-builder.git
cd autoapk-ai-builder
```

### 2. Configure environment
```bash
cp backend/.env.example backend/.env
nano backend/.env
```

Set at minimum:
```env
OPENAI_API_KEY=sk-your-openai-api-key
FRONTEND_URL=http://YOUR_SERVER_IP
```

### 3. Run setup (as root/sudo)
```bash
sudo bash scripts/setup.sh
```

This script:
1. Installs Docker + Docker Compose
2. Builds the `autoapk-builder` image (~10–20 min, one-time)
3. Builds and starts all services
4. Opens port 80

### 4. Open the app
```
http://your-server-ip
```

---

## Manual Setup (step-by-step)

### Step 1 — Install Docker
```bash
curl -fsSL https://get.docker.com | bash
sudo usermod -aG docker $USER
newgrp docker
```

### Step 2 — Build the Android SDK builder image
```bash
docker build -f docker/Dockerfile.builder -t autoapk-builder:latest .
```
> ⚠️ This downloads Android SDK (~2 GB), Flutter (~1 GB), JDK, Gradle.
> It only runs **once**. Subsequent builds use the cached image.

### Step 3 — Configure backend
```bash
cp backend/.env.example backend/.env
# Edit backend/.env with your OPENAI_API_KEY
```

### Step 4 — Start services
```bash
docker compose up -d --build
```

### Step 5 — Check status
```bash
docker compose ps
docker compose logs -f backend
```

---

## Environment Variables

| Variable                   | Default                    | Description                            |
|---------------------------|----------------------------|----------------------------------------|
| `PORT`                    | `3001`                     | Backend HTTP port                      |
| `REDIS_URL`               | `redis://redis:6379`       | Redis connection URL                   |
| `OPENAI_API_KEY`          | *(required)*               | OpenAI API key for AI error fixing     |
| `UPLOAD_DIR`              | `/app/uploads`             | Where uploads are stored               |
| `OUTPUT_DIR`              | `/app/outputs`             | Where finished APKs are stored         |
| `MAX_FILE_SIZE_MB`        | `500`                      | Max upload size in MB                  |
| `BUILD_TIMEOUT_SECONDS`   | `600`                      | Max build time (10 min)                |
| `MAX_RETRIES`             | `3`                        | AI retry attempts                      |
| `DOCKER_BUILDER_IMAGE`    | `autoapk-builder:latest`   | Builder Docker image name              |
| `FRONTEND_URL`            | `http://localhost:3000`    | CORS allowed origin                    |

---

## How It Works

### Build Flow
```
Upload ZIP/tar.gz
       │
       ▼
 Extract archive (safe path validation)
       │
       ▼
 Detect project type
 (Gradle / Flutter / React Native)
       │
       ▼
 Spawn Docker container with Android SDK
 Run build command:
   Gradle  → ./gradlew assembleDebug
   Flutter → flutter build apk
   RN      → cd android && ./gradlew assembleDebug
       │
       ├─ SUCCESS → Find APK → Store → Return download link
       │
       └─ FAILURE → Send logs to OpenAI GPT-4o
                         │
                         ▼
                   AI analyzes errors
                   Applies file fixes:
                   • local.properties
                   • build.gradle versions
                   • missing repositories
                   • Kotlin/Java compat
                         │
                         ▼
                   Retry (max 3×)
```

### AI Error Fixing
The AI (GPT-4o) receives:
- Build failure logs (last 4000 chars)
- Relevant project files (build.gradle, pubspec.yaml, etc.)
- Project type

It returns structured JSON with specific file modifications to fix the issue, which are applied automatically before retrying.

If OpenAI is not configured, a heuristic fixer applies common fixes:
- Creates `local.properties` with `sdk.dir`
- Makes `gradlew` executable
- Updates outdated `compileSdkVersion`
- Adds `google()` repository
- Updates Gradle wrapper version

---

## Security

| Measure                | Details                                                       |
|------------------------|---------------------------------------------------------------|
| Sandboxed builds       | Each build runs in isolated Docker container                  |
| No network in builds   | `NetworkMode: 'none'` — no internet access during build       |
| Path traversal         | All archive extraction validates paths                        |
| File size limit        | 500 MB max upload                                             |
| Rate limiting          | 20 requests / 15 min per IP                                   |
| Build timeout          | 600s hard timeout per build                                   |
| Memory limit           | 4 GB RAM per build container                                  |
| Read-only mounts       | Only workspace is writable                                    |

---

## Folder Structure

```
autoapk-ai-builder/
├── backend/
│   ├── src/
│   │   ├── server.js              # Express app + Socket.IO
│   │   ├── routes/
│   │   │   ├── upload.js          # POST /api/upload
│   │   │   ├── build.js           # GET  /api/build/:jobId
│   │   │   └── status.js          # GET  /api/status/queue
│   │   ├── workers/
│   │   │   └── buildWorker.js     # BullMQ worker (orchestrates build)
│   │   ├── queue/
│   │   │   └── buildQueue.js      # BullMQ queue setup
│   │   ├── services/
│   │   │   ├── extractor.js       # Safe archive extraction
│   │   │   ├── detector.js        # Project type detection
│   │   │   ├── dockerBuilder.js   # Docker container runner
│   │   │   ├── aiFixService.js    # OpenAI error fixer
│   │   │   ├── apkFinder.js       # Finds APK in build output
│   │   │   └── socketService.js   # WebSocket handlers
│   │   └── utils/
│   │       └── logger.js          # Winston logger
│   ├── package.json
│   └── .env.example
├── frontend/
│   ├── src/
│   │   ├── main.jsx
│   │   ├── App.jsx
│   │   ├── index.css
│   │   └── components/
│   │       ├── Header.jsx         # App header
│   │       ├── UploadZone.jsx     # Drag & drop upload
│   │       ├── BuildDashboard.jsx # Live build view
│   │       ├── StepPipeline.jsx   # Progress steps UI
│   │       ├── LogViewer.jsx      # Terminal log viewer
│   │       └── QueueStatus.jsx    # Queue stats
│   ├── package.json
│   ├── vite.config.js
│   └── tailwind.config.js
├── docker/
│   ├── Dockerfile.builder         # Android SDK + Flutter + Gradle
│   ├── Dockerfile.backend         # Node.js backend
│   ├── Dockerfile.frontend        # React + Nginx
│   └── nginx.conf                 # Nginx reverse proxy config
├── scripts/
│   └── setup.sh                   # One-command server setup
├── docker-compose.yml
└── README.md
```

---

## Troubleshooting

### Build fails with "SDK not found"
The builder image correctly sets `ANDROID_HOME=/opt/android-sdk`. If you see this, ensure `local.properties` is NOT overriding it. The AI fixer will handle this automatically.

### Out of disk space
APK builds can use 4–8 GB per build. Clean up:
```bash
docker volume prune     # Remove old workspace volumes
docker image prune -a   # Remove dangling images
```

### Socket.IO not connecting
Ensure your firewall allows port 80 and that Nginx is running:
```bash
docker compose logs frontend
```

### Builder image build fails
If internet is slow or a download fails:
```bash
docker build -f docker/Dockerfile.builder -t autoapk-builder:latest . --no-cache
```

### View live backend logs
```bash
docker compose logs -f backend
```

### Access Redis directly
```bash
docker compose exec redis redis-cli
```

---

## Scaling

For high traffic, increase worker concurrency in `buildWorker.js`:
```js
const worker = new Worker('apk-builds', processor, {
  concurrency: 4, // Build 4 APKs simultaneously
  ...
});
```
And ensure your server has enough CPU/RAM (roughly 4 GB RAM per concurrent build).

---

## HTTPS Setup (with Let's Encrypt)

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com
```

Then update `backend/.env`:
```env
FRONTEND_URL=https://your-domain.com
```

---

## License

MIT — see LICENSE for details.
