# AutoAPK Builder Image
# This image is used by the backend to run builds in isolated containers
FROM ubuntu:22.04

ENV DEBIAN_FRONTEND=noninteractive
ENV JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
ENV ANDROID_HOME=/opt/android-sdk
ENV ANDROID_SDK_ROOT=/opt/android-sdk
ENV FLUTTER_HOME=/opt/flutter
ENV PATH="${PATH}:${JAVA_HOME}/bin:${ANDROID_HOME}/cmdline-tools/latest/bin:${ANDROID_HOME}/platform-tools:${FLUTTER_HOME}/bin"
ENV GRADLE_OPTS="-Xmx2g -Dorg.gradle.daemon=false -Dorg.gradle.parallel=false"

# ── System packages ──────────────────────────────────────────────────────────
RUN apt-get update && apt-get install -y \
    openjdk-17-jdk \
    wget curl unzip git \
    libgl1-mesa-dev \
    python3 python3-pip \
    nodejs npm \
    lib32z1 lib32stdc++6 \
    build-essential \
    clang cmake ninja-build \
    pkg-config libgtk-3-dev \
    && rm -rf /var/lib/apt/lists/*

# ── Android SDK Command-Line Tools ───────────────────────────────────────────
RUN mkdir -p ${ANDROID_HOME}/cmdline-tools \
    && wget -q "https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip" -O /tmp/cmdtools.zip \
    && unzip -q /tmp/cmdtools.zip -d /tmp/cmdtools \
    && mv /tmp/cmdtools/cmdline-tools ${ANDROID_HOME}/cmdline-tools/latest \
    && rm -rf /tmp/cmdtools /tmp/cmdtools.zip

# Accept licenses and install SDK packages
RUN yes | sdkmanager --licenses 2>/dev/null || true \
    && sdkmanager \
        "platforms;android-34" \
        "platforms;android-33" \
        "platforms;android-32" \
        "platforms;android-31" \
        "build-tools;34.0.0" \
        "build-tools;33.0.2" \
        "build-tools;30.0.3" \
        "platform-tools" \
        "ndk;25.1.8937393" \
        "cmake;3.22.1" \
    && yes | sdkmanager --licenses 2>/dev/null || true

# ── Gradle (system-level fallback) ───────────────────────────────────────────
RUN wget -q "https://services.gradle.org/distributions/gradle-8.4-bin.zip" -O /tmp/gradle.zip \
    && unzip -q /tmp/gradle.zip -d /opt \
    && ln -s /opt/gradle-8.4/bin/gradle /usr/local/bin/gradle \
    && rm /tmp/gradle.zip

# ── Flutter SDK ───────────────────────────────────────────────────────────────
RUN git clone --depth 1 --branch stable https://github.com/flutter/flutter.git ${FLUTTER_HOME} \
    && flutter precache --android \
    && flutter config --android-sdk ${ANDROID_HOME} \
    && flutter config --no-analytics \
    && yes | flutter doctor --android-licenses 2>/dev/null || true

# ── Node.js tools for React Native ───────────────────────────────────────────
RUN npm install -g @react-native-community/cli react-native-cli yarn

# ── Gradle cache warmup (speeds up first build) ──────────────────────────────
RUN mkdir -p /root/.gradle \
    && echo "org.gradle.daemon=false\norg.gradle.parallel=false" >> /root/.gradle/gradle.properties

# ── Cleanup ──────────────────────────────────────────────────────────────────
RUN apt-get autoremove -y && apt-get clean

# Default working directory (will be overridden by volume mount)
WORKDIR /workspace

# The container runs a build command passed by the backend
CMD ["bash"]
