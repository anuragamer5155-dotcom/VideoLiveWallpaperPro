#!/bin/bash
# AutoAPK AI Builder - Ubuntu Server Setup Script
# Run as root or with sudo on Ubuntu 22.04+

set -euo pipefail
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'

info()    { echo -e "${CYAN}[INFO]${NC} $*"; }
success() { echo -e "${GREEN}[OK]${NC} $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC} $*"; }
error()   { echo -e "${RED}[ERROR]${NC} $*"; exit 1; }

echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║     AutoAPK AI Builder — Server Setup        ║"
echo "╚══════════════════════════════════════════════╝"
echo ""

# ── Check OS ──────────────────────────────────────────────────────────────────
if ! grep -qi "ubuntu" /etc/os-release 2>/dev/null; then
  warn "This script is designed for Ubuntu. Proceeding anyway..."
fi

# ── Docker ────────────────────────────────────────────────────────────────────
if ! command -v docker &>/dev/null; then
  info "Installing Docker..."
  curl -fsSL https://get.docker.com | bash
  systemctl enable docker
  systemctl start docker
  usermod -aG docker "$SUDO_USER" 2>/dev/null || true
  success "Docker installed"
else
  success "Docker already installed: $(docker --version)"
fi

# ── Docker Compose plugin ──────────────────────────────────────────────────────
if ! docker compose version &>/dev/null 2>&1; then
  info "Installing Docker Compose plugin..."
  apt-get install -y docker-compose-plugin
  success "Docker Compose plugin installed"
else
  success "Docker Compose: $(docker compose version)"
fi

# ── System dependencies ────────────────────────────────────────────────────────
info "Installing system dependencies..."
apt-get update -qq
apt-get install -y -qq curl wget git unzip htop
success "System dependencies installed"

# ── Configure environment ──────────────────────────────────────────────────────
if [ ! -f ./backend/.env ]; then
  info "Creating backend .env from template..."
  cp ./backend/.env.example ./backend/.env
  
  # Generate a random secret
  SECRET=$(openssl rand -hex 32)
  
  echo ""
  warn "═══════════════════════════════════════════════════"
  warn "IMPORTANT: Edit ./backend/.env and set:"
  warn "  OPENAI_API_KEY=sk-your-key-here"
  warn "  FRONTEND_URL=http://your-server-ip"
  warn "═══════════════════════════════════════════════════"
  echo ""
fi

# ── Build the Android SDK builder image ───────────────────────────────────────
info "Building the Android SDK builder Docker image..."
info "This will take 10–20 minutes the first time (downloading Android SDK, Flutter, etc.)"
echo ""

docker build \
  -f docker/Dockerfile.builder \
  -t autoapk-builder:latest \
  --progress=plain \
  . 2>&1 | tee /tmp/autoapk-builder-build.log

if [ ${PIPESTATUS[0]} -ne 0 ]; then
  error "Failed to build autoapk-builder image. Check /tmp/autoapk-builder-build.log"
fi

success "autoapk-builder:latest image built"

# ── Build and start services ───────────────────────────────────────────────────
info "Building and starting AutoAPK services..."
docker compose build --parallel
docker compose up -d

success "Services started!"

echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║  AutoAPK AI Builder is running!                              ║"
echo "║                                                              ║"
echo "║  Open in browser: http://$(hostname -I | awk '{print $1}')                    ║"
echo "║  API health:      http://$(hostname -I | awk '{print $1}')/health              ║"
echo "║                                                              ║"
echo "║  Useful commands:                                            ║"
echo "║    docker compose logs -f backend   # live backend logs      ║"
echo "║    docker compose logs -f frontend  # nginx logs             ║"
echo "║    docker compose down              # stop services          ║"
echo "║    docker compose ps                # service status         ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""

warn "Don't forget to set your OPENAI_API_KEY in ./backend/.env then:"
echo "  docker compose restart backend"
