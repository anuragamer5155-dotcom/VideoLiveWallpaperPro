#!/bin/bash
# monitor.sh - Quick health check for AutoAPK services

set -euo pipefail
GREEN='\033[0;32m'; RED='\033[0;31m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'

ok()   { echo -e "${GREEN}  ✓${NC} $*"; }
fail() { echo -e "${RED}  ✗${NC} $*"; }
warn() { echo -e "${YELLOW}  ⚠${NC} $*"; }
info() { echo -e "${CYAN}  →${NC} $*"; }

echo ""
echo "══════════════════════════════════════"
echo "  AutoAPK AI Builder — Health Check   "
echo "══════════════════════════════════════"
echo ""

# Docker services
echo "Services:"
for svc in frontend backend redis; do
  status=$(docker compose ps --format json "$svc" 2>/dev/null | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('State','?'))" 2>/dev/null || echo "unknown")
  if [ "$status" = "running" ]; then
    ok "$svc ($status)"
  else
    fail "$svc ($status)"
  fi
done

echo ""
echo "API Health:"

# Backend health
resp=$(curl -sf http://localhost:3001/health 2>/dev/null || echo "FAIL")
if echo "$resp" | grep -q "ok"; then
  ok "Backend API (port 3001)"
else
  fail "Backend API unreachable"
fi

# Frontend
resp=$(curl -sf -o /dev/null -w "%{http_code}" http://localhost:80 2>/dev/null || echo "000")
if [ "$resp" = "200" ]; then
  ok "Frontend (port 80)"
else
  fail "Frontend (HTTP $resp)"
fi

# Queue stats
echo ""
echo "Queue Stats:"
stats=$(curl -sf http://localhost:3001/api/status/queue 2>/dev/null || echo "{}")
echo "$stats" | python3 -c "
import sys, json
try:
  d = json.load(sys.stdin)
  print(f'  Active: {d.get(\"active\",\"?\")}  Waiting: {d.get(\"waiting\",\"?\")}  Completed: {d.get(\"completed\",\"?\")}  Failed: {d.get(\"failed\",\"?\")}')
except:
  print('  Could not parse queue stats')
"

# Docker builder image
echo ""
echo "Builder Image:"
if docker image inspect autoapk-builder:latest &>/dev/null; then
  size=$(docker image inspect autoapk-builder:latest --format '{{.Size}}' | awk '{printf "%.1f GB", $1/1073741824}')
  ok "autoapk-builder:latest ($size)"
else
  fail "autoapk-builder:latest NOT FOUND — run: docker build -f docker/Dockerfile.builder -t autoapk-builder:latest ."
fi

# Disk space
echo ""
echo "Disk:"
df -h / | tail -1 | awk '{printf "  Root: %s used, %s free (%s)\n", $3, $4, $5}'

# Redis memory
echo ""
echo "Redis:"
redis_info=$(docker compose exec -T redis redis-cli info memory 2>/dev/null || echo "")
if [ -n "$redis_info" ]; then
  used=$(echo "$redis_info" | grep "used_memory_human" | head -1 | tr -d '\r' | cut -d: -f2)
  ok "Memory used: $used"
else
  warn "Redis not reachable"
fi

echo ""
echo "══════════════════════════════════════"
