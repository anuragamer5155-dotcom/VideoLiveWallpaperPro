#!/bin/bash
# cleanup.sh - Remove old APK outputs and workspaces to free disk space
# Run via cron: 0 3 * * * /path/to/scripts/cleanup.sh >> /var/log/autoapk-cleanup.log 2>&1

set -euo pipefail

OUTPUTS_DIR="${OUTPUTS_DIR:-/var/lib/docker/volumes/autoapk-ai-builder_outputs_data/_data}"
UPLOADS_DIR="${UPLOADS_DIR:-/var/lib/docker/volumes/autoapk-ai-builder_uploads_data/_data}"
WORKSPACES_DIR="${WORKSPACES_DIR:-/var/lib/docker/volumes/autoapk-ai-builder_workspaces_data/_data}"
MAX_AGE_HOURS="${MAX_AGE_HOURS:-24}"

echo "[$(date)] Starting cleanup (files older than ${MAX_AGE_HOURS}h)..."

# Remove old outputs (APKs)
if [ -d "$OUTPUTS_DIR" ]; then
  deleted=$(find "$OUTPUTS_DIR" -mindepth 1 -maxdepth 1 -type d -mmin +$((MAX_AGE_HOURS * 60)) -print -exec rm -rf {} \; | wc -l)
  echo "[$(date)] Deleted $deleted old APK output(s)"
fi

# Remove old uploads
if [ -d "$UPLOADS_DIR" ]; then
  deleted=$(find "$UPLOADS_DIR" -type f -mmin +$((MAX_AGE_HOURS * 60)) -print -delete | wc -l)
  echo "[$(date)] Deleted $deleted old upload(s)"
fi

# Remove leftover workspaces (should already be cleaned by worker, but just in case)
if [ -d "$WORKSPACES_DIR" ]; then
  deleted=$(find "$WORKSPACES_DIR" -mindepth 1 -maxdepth 1 -type d -mmin +$((MAX_AGE_HOURS * 60)) -print -exec rm -rf {} \; | wc -l)
  echo "[$(date)] Deleted $deleted leftover workspace(s)"
fi

# Remove stopped build containers
stopped=$(docker ps -a --filter "ancestor=autoapk-builder:latest" --filter "status=exited" -q)
if [ -n "$stopped" ]; then
  count=$(echo "$stopped" | wc -l)
  echo "$stopped" | xargs docker rm -f 2>/dev/null || true
  echo "[$(date)] Removed $count stopped build container(s)"
fi

# Docker system prune (dangling images/volumes only, not named volumes)
docker image prune -f --filter "dangling=true" 2>/dev/null || true

echo "[$(date)] Cleanup complete."
df -h / | tail -1 | awk '{print "[disk] used=" $3 " free=" $4 " (" $5 " used)"}'
