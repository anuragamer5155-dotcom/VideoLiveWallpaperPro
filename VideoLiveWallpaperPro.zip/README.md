# Video Live Wallpaper Pro

A lightweight Android app that lets you set any video from your phone as a live wallpaper.

## Features

- **Pick any video** from your phone storage
- **Live wallpaper engine** using WallpaperService API
- **ExoPlayer** (Media3) for smooth, hardware-accelerated playback
- **Apply wallpaper** to Home screen, Lock screen, or Both
- **Auto-loop** video continuously
- **Battery-friendly** — pauses when screen is off, resumes when screen is on
- **Mute/Unmute** toggle for video audio
- **Fit/Crop** toggle for video scaling
- **Full-screen preview** before applying
- **Modern dark UI** with Material Design 3
- **MVVM architecture** with ViewModel and LiveData
- **Optimized** for low-end devices with hardware acceleration
- **Runtime permissions** handled for all Android versions (API 21+)

## Project Structure

```
VideoLiveWallpaperPro/
├── app/
│   ├── build.gradle.kts              # App-level build config
│   ├── proguard-rules.pro            # ProGuard rules for release
│   └── src/main/
│       ├── AndroidManifest.xml       # App manifest with permissions & services
│       ├── java/com/videowallpaper/pro/
│       │   ├── service/
│       │   │   └── VideoWallpaperService.kt    # Live wallpaper engine (ExoPlayer)
│       │   ├── ui/
│       │   │   ├── main/
│       │   │   │   └── MainActivity.kt         # Main screen (select, preview, apply)
│       │   │   └── preview/
│       │   │       └── PreviewActivity.kt      # Full-screen video preview
│       │   ├── viewmodel/
│       │   │   └── MainViewModel.kt            # MVVM ViewModel
│       │   └── util/
│       │       ├── PreferenceManager.kt        # SharedPreferences helper
│       │       └── PermissionHelper.kt         # Runtime permission helper
│       └── res/
│           ├── layout/
│           │   ├── activity_main.xml           # Main screen layout
│           │   ├── activity_preview.xml        # Preview screen layout
│           │   └── dialog_apply_wallpaper.xml  # Apply options dialog
│           ├── values/
│           │   ├── colors.xml                  # Dark theme colors
│           │   ├── strings.xml                 # All string resources
│           │   └── themes.xml                  # Material 3 dark theme
│           ├── drawable/                       # Vector icons & shapes
│           ├── xml/
│           │   └── wallpaper.xml               # Wallpaper service metadata
│           └── mipmap-*/                       # Launcher icons
├── build.gradle.kts                  # Root build config
├── settings.gradle.kts               # Project settings
├── gradle.properties                 # Gradle properties
└── gradle/wrapper/
    └── gradle-wrapper.properties     # Gradle wrapper config
```

## Setup Instructions

### Prerequisites
- **Android Studio** Hedgehog (2023.1) or later
- **JDK 17** (bundled with Android Studio)
- **Android SDK** with API 34 installed

### Step-by-Step Setup

1. **Download the project**
   - Download or copy the entire `VideoLiveWallpaperPro/` folder to your computer

2. **Open in Android Studio**
   - Launch Android Studio
   - Click "Open" and select the `VideoLiveWallpaperPro/` folder
   - Wait for Gradle sync to complete (may take a few minutes on first run)

3. **Sync Gradle**
   - If prompted, click "Sync Now" in the yellow banner
   - Android Studio will download all dependencies automatically

4. **Run on a device/emulator**
   - Connect a physical Android device via USB (recommended) or start an emulator
   - Click the green "Run" button (or press Shift+F10)
   - Select your device and click OK

### Building a Release APK

1. **Open Terminal** in Android Studio (View → Tool Windows → Terminal)

2. **Run the build command:**
   ```bash
   ./gradlew assembleRelease
   ```

3. **Find the APK** at:
   ```
   app/build/outputs/apk/release/app-release-unsigned.apk
   ```

4. **Sign the APK** (required for installation):
   - Go to Build → Generate Signed Bundle/APK
   - Select APK
   - Create a new keystore or use an existing one
   - Fill in the signing details
   - Select "release" build type
   - Click Finish

   Or sign via command line:
   ```bash
   # Create a keystore (one time only)
   keytool -genkey -v -keystore my-release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias my-key

   # Sign the APK
   jarsigner -verbose -sigalg SHA256withRSA -digestalg SHA-256 -keystore my-release-key.jks app/build/outputs/apk/release/app-release-unsigned.apk my-key

   # Align the APK (optional but recommended)
   zipalign -v 4 app/build/outputs/apk/release/app-release-unsigned.apk app-release.apk
   ```

5. **Install on device:**
   ```bash
   adb install app-release.apk
   ```

### Building a Debug APK (faster, no signing needed)

```bash
./gradlew assembleDebug
```
Find it at: `app/build/outputs/apk/debug/app-debug.apk`

## How to Use

1. **Open the app** — you'll see the dark themed main screen
2. **Tap "Select Video"** — grant storage permission when prompted, then pick any video
3. **Adjust settings** — toggle Mute/Unmute and Fit/Crop as desired
4. **Tap "Preview"** — see full-screen preview of how the wallpaper will look
5. **Tap "Apply Wallpaper"** — choose Home Screen, Lock Screen, or Both
6. **Confirm** in the system wallpaper picker — your video is now your live wallpaper!

## Technical Details

- **Min SDK**: 21 (Android 5.0 Lollipop)
- **Target SDK**: 34 (Android 14)
- **Language**: Kotlin
- **Video Player**: ExoPlayer (Media3 1.2.1)
- **Architecture**: MVVM (ViewModel + LiveData)
- **UI**: Material Design 3 with ViewBinding
- **Permissions**: READ_EXTERNAL_STORAGE (API < 33) / READ_MEDIA_VIDEO (API 33+)

## Performance Optimizations

- Uses ExoPlayer (Media3) instead of MediaPlayer for hardware-accelerated decoding
- Pauses video playback when screen is off (battery saver)
- Pauses when wallpaper is not visible (app drawer, etc.)
- Hardware acceleration enabled in manifest
- ProGuard minification enabled for release builds
- Proper resource cleanup to prevent memory leaks
