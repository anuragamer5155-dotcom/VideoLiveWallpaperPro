package com.videowallpaper.pro.util

import android.content.Context
import android.content.SharedPreferences

/**
 * Manages user preferences for video wallpaper settings.
 * Stores video URI, mute state, and scaling mode persistently.
 */
object PreferenceManager {

    private const val PREF_NAME = "video_wallpaper_prefs"
    private const val KEY_VIDEO_URI = "video_uri"
    private const val KEY_IS_MUTED = "is_muted"
    private const val KEY_SCALE_TYPE = "scale_type"

    // Scale type constants
    const val SCALE_FIT = 0
    const val SCALE_CROP = 1

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
    }

    /** Save the selected video URI */
    fun setVideoUri(context: Context, uri: String) {
        getPrefs(context).edit().putString(KEY_VIDEO_URI, uri).apply()
    }

    /** Get the saved video URI, or null if none */
    fun getVideoUri(context: Context): String? {
        return getPrefs(context).getString(KEY_VIDEO_URI, null)
    }

    /** Save the mute preference */
    fun setMuted(context: Context, muted: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_IS_MUTED, muted).apply()
    }

    /** Check if audio should be muted */
    fun isMuted(context: Context): Boolean {
        return getPrefs(context).getBoolean(KEY_IS_MUTED, true)
    }

    /** Save the scaling mode (fit or crop) */
    fun setScaleType(context: Context, scaleType: Int) {
        getPrefs(context).edit().putInt(KEY_SCALE_TYPE, scaleType).apply()
    }

    /** Get the current scaling mode */
    fun getScaleType(context: Context): Int {
        return getPrefs(context).getInt(KEY_SCALE_TYPE, SCALE_CROP)
    }
}
