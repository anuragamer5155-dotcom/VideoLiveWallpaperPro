package com.videowallpaper.pro.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.videowallpaper.pro.util.PreferenceManager

/**
 * ViewModel for the main screen following MVVM architecture.
 * Manages the selected video URI and user preferences (mute, scale mode).
 */
class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val _videoUri = MutableLiveData<Uri?>()
    val videoUri: LiveData<Uri?> = _videoUri

    private val _isMuted = MutableLiveData<Boolean>()
    val isMuted: LiveData<Boolean> = _isMuted

    private val _scaleType = MutableLiveData<Int>()
    val scaleType: LiveData<Int> = _scaleType

    private val _statusMessage = MutableLiveData<String>()
    val statusMessage: LiveData<String> = _statusMessage

    init {
        // Load saved preferences
        val context = application.applicationContext
        val savedUri = PreferenceManager.getVideoUri(context)
        if (savedUri != null) {
            _videoUri.value = Uri.parse(savedUri)
        }
        _isMuted.value = PreferenceManager.isMuted(context)
        _scaleType.value = PreferenceManager.getScaleType(context)
    }

    /** Called when a user selects a video from storage */
    fun onVideoSelected(uri: Uri) {
        _videoUri.value = uri
        PreferenceManager.setVideoUri(getApplication(), uri.toString())
        _statusMessage.value = "Video selected and ready"
    }

    /** Toggle the mute state */
    fun toggleMute() {
        val newValue = _isMuted.value != true
        _isMuted.value = newValue
        PreferenceManager.setMuted(getApplication(), newValue)
    }

    /** Toggle between fit and crop scaling modes */
    fun toggleScaleType() {
        val current = _scaleType.value ?: PreferenceManager.SCALE_CROP
        val newValue = if (current == PreferenceManager.SCALE_FIT) {
            PreferenceManager.SCALE_CROP
        } else {
            PreferenceManager.SCALE_FIT
        }
        _scaleType.value = newValue
        PreferenceManager.setScaleType(getApplication(), newValue)
    }

    /** Check if a video has been selected */
    fun hasVideo(): Boolean = _videoUri.value != null
}
