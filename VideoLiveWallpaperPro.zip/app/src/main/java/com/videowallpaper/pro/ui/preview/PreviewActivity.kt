package com.videowallpaper.pro.ui.preview

import android.net.Uri
import android.os.Bundle
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.videowallpaper.pro.databinding.ActivityPreviewBinding
import com.videowallpaper.pro.util.PreferenceManager

/**
 * Full-screen preview activity that shows how the video will look as a wallpaper.
 * Uses ExoPlayer with auto-loop to simulate the wallpaper experience.
 */
class PreviewActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_VIDEO_URI = "extra_video_uri"
    }

    private lateinit var binding: ActivityPreviewBinding
    private var player: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Full screen immersive mode for accurate wallpaper preview
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )

        binding = ActivityPreviewBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Back button to return to main screen
        binding.btnBack.setOnClickListener {
            finish()
        }

        // Get the video URI passed from MainActivity
        val uriString = intent.getStringExtra(EXTRA_VIDEO_URI)
        if (uriString != null) {
            initializePlayer(Uri.parse(uriString))
        } else {
            finish()
        }
    }

    /**
     * Set up ExoPlayer for full-screen video preview.
     * Applies the user's mute and scaling preferences.
     */
    private fun initializePlayer(uri: Uri) {
        try {
            player = ExoPlayer.Builder(this)
                .build()
                .apply {
                    // Attach player to the PlayerView
                    binding.playerView.player = this

                    // Load the video
                    val mediaItem = MediaItem.fromUri(uri)
                    setMediaItem(mediaItem)

                    // Infinite loop to simulate wallpaper behavior
                    repeatMode = Player.REPEAT_MODE_ALL

                    // Apply mute setting from preferences
                    val isMuted = PreferenceManager.isMuted(this@PreviewActivity)
                    volume = if (isMuted) 0f else 1f

                    // Apply scale type from preferences
                    val scaleType = PreferenceManager.getScaleType(this@PreviewActivity)
                    videoScalingMode = if (scaleType == PreferenceManager.SCALE_FIT) {
                        androidx.media3.common.C.VIDEO_SCALING_MODE_SCALE_TO_FIT
                    } else {
                        androidx.media3.common.C.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING
                    }

                    // Start playback
                    prepare()
                    playWhenReady = true
                }
        } catch (e: Exception) {
            finish()
        }
    }

    override fun onPause() {
        super.onPause()
        player?.playWhenReady = false
    }

    override fun onResume() {
        super.onResume()
        player?.playWhenReady = true
    }

    override fun onDestroy() {
        super.onDestroy()
        player?.apply {
            stop()
            release()
        }
        player = null
    }
}
