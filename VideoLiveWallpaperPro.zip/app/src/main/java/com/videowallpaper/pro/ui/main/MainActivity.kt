package com.videowallpaper.pro.ui.main

import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.videowallpaper.pro.R
import com.videowallpaper.pro.databinding.ActivityMainBinding
import com.videowallpaper.pro.databinding.DialogApplyWallpaperBinding
import com.videowallpaper.pro.service.VideoWallpaperService
import com.videowallpaper.pro.ui.preview.PreviewActivity
import com.videowallpaper.pro.util.PermissionHelper
import com.videowallpaper.pro.util.PreferenceManager
import com.videowallpaper.pro.viewmodel.MainViewModel

/**
 * Main activity with the primary UI for selecting, previewing, and applying video wallpapers.
 * Uses MVVM pattern with ViewBinding for clean architecture.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: MainViewModel by viewModels()

    // Permission request launcher
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            openVideoPicker()
        } else {
            Toast.makeText(this, R.string.permission_required, Toast.LENGTH_LONG).show()
        }
    }

    // Video picker launcher - handles the selected video URI
    private val videoPickerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let { selectedUri ->
            // Take persistent permission so the wallpaper service can access it later
            try {
                contentResolver.takePersistableUriPermission(
                    selectedUri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (e: Exception) {
                // Some providers don't support persistable permissions
            }
            viewModel.onVideoSelected(selectedUri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupObservers()
        setupClickListeners()
    }

    /** Observe ViewModel LiveData for reactive UI updates */
    private fun setupObservers() {
        // Update thumbnail when video is selected
        viewModel.videoUri.observe(this) { uri ->
            if (uri != null) {
                showVideoThumbnail(uri)
                binding.placeholderLayout.visibility = android.view.View.GONE
                binding.ivThumbnail.visibility = android.view.View.VISIBLE
                binding.optionsRow.visibility = android.view.View.VISIBLE
                binding.tvStatus.text = getString(R.string.video_selected)
            } else {
                binding.placeholderLayout.visibility = android.view.View.VISIBLE
                binding.ivThumbnail.visibility = android.view.View.GONE
                binding.optionsRow.visibility = android.view.View.GONE
                binding.tvStatus.text = ""
            }
        }

        // Update mute chip text
        viewModel.isMuted.observe(this) { muted ->
            binding.chipMute.text = if (muted) getString(R.string.unmute) else getString(R.string.mute)
            binding.chipMute.isChecked = muted
        }

        // Update scale type chip text
        viewModel.scaleType.observe(this) { scaleType ->
            binding.chipFitCrop.text = if (scaleType == PreferenceManager.SCALE_FIT) {
                getString(R.string.crop_screen)
            } else {
                getString(R.string.fit_screen)
            }
        }

        // Show status messages
        viewModel.statusMessage.observe(this) { message ->
            if (!message.isNullOrEmpty()) {
                binding.tvStatus.text = message
            }
        }
    }

    /** Set up button click handlers */
    private fun setupClickListeners() {
        // Select Video - check permissions first
        binding.btnSelectVideo.setOnClickListener {
            if (PermissionHelper.hasStoragePermission(this)) {
                openVideoPicker()
            } else {
                permissionLauncher.launch(PermissionHelper.getStoragePermission())
            }
        }

        // Preview - open full-screen preview of selected video
        binding.btnPreview.setOnClickListener {
            if (viewModel.hasVideo()) {
                val intent = Intent(this, PreviewActivity::class.java).apply {
                    putExtra(PreviewActivity.EXTRA_VIDEO_URI, viewModel.videoUri.value.toString())
                }
                startActivity(intent)
            } else {
                Toast.makeText(this, R.string.select_video_first, Toast.LENGTH_SHORT).show()
            }
        }

        // Apply Wallpaper - show bottom sheet with options
        binding.btnApplyWallpaper.setOnClickListener {
            if (viewModel.hasVideo()) {
                showApplyDialog()
            } else {
                Toast.makeText(this, R.string.select_video_first, Toast.LENGTH_SHORT).show()
            }
        }

        // Toggle mute/unmute
        binding.chipMute.setOnClickListener {
            viewModel.toggleMute()
        }

        // Toggle fit/crop
        binding.chipFitCrop.setOnClickListener {
            viewModel.toggleScaleType()
        }
    }

    /** Open the system video picker using SAF (Storage Access Framework) */
    private fun openVideoPicker() {
        try {
            videoPickerLauncher.launch(arrayOf("video/*"))
        } catch (e: Exception) {
            Toast.makeText(this, "Unable to open video picker", Toast.LENGTH_SHORT).show()
        }
    }

    /** Load and display a thumbnail for the selected video */
    private fun showVideoThumbnail(uri: Uri) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val thumbnail = contentResolver.loadThumbnail(
                    uri,
                    android.util.Size(640, 360),
                    null
                )
                binding.ivThumbnail.setImageBitmap(thumbnail)
            } else {
                // Fallback for older devices - just show the placeholder colored
                binding.ivThumbnail.setImageResource(R.drawable.video_placeholder)
            }
        } catch (e: Exception) {
            binding.ivThumbnail.setImageResource(R.drawable.video_placeholder)
        }
    }

    /**
     * Show a bottom sheet dialog with options to apply wallpaper to:
     * - Home screen only
     * - Lock screen only  
     * - Both screens
     */
    private fun showApplyDialog() {
        val dialog = BottomSheetDialog(this)
        val dialogBinding = DialogApplyWallpaperBinding.inflate(layoutInflater)
        dialog.setContentView(dialogBinding.root)

        dialogBinding.btnHomeScreen.setOnClickListener {
            dialog.dismiss()
            applyWallpaper(WallpaperManager.FLAG_SYSTEM)
        }

        dialogBinding.btnLockScreen.setOnClickListener {
            dialog.dismiss()
            applyWallpaper(WallpaperManager.FLAG_LOCK)
        }

        dialogBinding.btnBothScreens.setOnClickListener {
            dialog.dismiss()
            applyWallpaper(WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK)
        }

        dialog.show()
    }

    /**
     * Apply the video as a live wallpaper using the system's wallpaper chooser intent.
     * The WallpaperService handles the actual rendering.
     * 
     * @param flags WallpaperManager flags indicating which screen(s) to set
     */
    private fun applyWallpaper(flags: Int) {
        try {
            // Launch the system wallpaper preview/setter for our service
            val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
                putExtra(
                    WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                    ComponentName(this@MainActivity, VideoWallpaperService::class.java)
                )
            }
            startActivity(intent)
        } catch (e: Exception) {
            // Fallback: try the generic live wallpaper picker
            try {
                val intent = Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER)
                startActivity(intent)
            } catch (e2: Exception) {
                Toast.makeText(this, R.string.apply_failed, Toast.LENGTH_LONG).show()
            }
        }
    }
}
