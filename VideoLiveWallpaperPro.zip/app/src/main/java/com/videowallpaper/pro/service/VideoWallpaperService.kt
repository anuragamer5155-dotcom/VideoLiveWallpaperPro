package com.videowallpaper.pro.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.service.wallpaper.WallpaperService
import android.util.Log
import android.view.SurfaceHolder
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer
import com.videowallpaper.pro.util.PreferenceManager

/**
 * Live wallpaper service that renders a video using ExoPlayer.
 * 
 * Features:
 * - Auto-loops the video continuously
 * - Pauses when screen is off to save battery
 * - Resumes when screen is on
 * - Supports mute/unmute via preferences
 * - Supports fit/crop scaling via preferences
 * - Optimized for low-end devices with hardware acceleration
 * - Limits resolution to 720p for performance
 */
class VideoWallpaperService : WallpaperService() {

    companion object {
        private const val TAG = "VideoWallpaperService"
        // Maximum resolution cap for performance on low-end devices
        const val MAX_WIDTH = 1280
        const val MAX_HEIGHT = 720
    }

    override fun onCreateEngine(): Engine {
        return VideoEngine()
    }

    /**
     * The wallpaper engine that manages ExoPlayer and renders video to the wallpaper surface.
     */
    inner class VideoEngine : Engine() {

        private var player: ExoPlayer? = null
        private var videoUri: Uri? = null

        // Broadcast receiver to detect screen on/off events for battery optimization
        private val screenReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                when (intent?.action) {
                    Intent.ACTION_SCREEN_OFF -> pausePlayer()
                    Intent.ACTION_SCREEN_ON -> resumePlayer()
                }
            }
        }

        override fun onCreate(surfaceHolder: SurfaceHolder?) {
            super.onCreate(surfaceHolder)

            // Load saved video URI from preferences
            val uriString = PreferenceManager.getVideoUri(this@VideoWallpaperService)
            if (uriString != null) {
                videoUri = Uri.parse(uriString)
            }

            // Register screen on/off receiver to pause/resume playback
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_SCREEN_ON)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                registerReceiver(screenReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                registerReceiver(screenReceiver, filter)
            }
        }

        override fun onSurfaceCreated(holder: SurfaceHolder) {
            super.onSurfaceCreated(holder)
            initializePlayer(holder)
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            super.onSurfaceDestroyed(holder)
            releasePlayer()
        }

        override fun onVisibilityChanged(visible: Boolean) {
            super.onVisibilityChanged(visible)
            // Pause when not visible (e.g., app drawer open) to save resources
            if (visible) {
                resumePlayer()
            } else {
                pausePlayer()
            }
        }

        override fun onDestroy() {
            super.onDestroy()
            releasePlayer()
            try {
                unregisterReceiver(screenReceiver)
            } catch (e: Exception) {
                Log.w(TAG, "Receiver already unregistered", e)
            }
        }

        /**
         * Initialize ExoPlayer with the selected video.
         * Sets up looping, mute state, and attaches to the wallpaper surface.
         */
        private fun initializePlayer(holder: SurfaceHolder) {
            val uri = videoUri ?: return

            try {
                // Build ExoPlayer with performance optimizations
                player = ExoPlayer.Builder(this@VideoWallpaperService)
                    .build()
                    .apply {
                        // Set the video to render on the wallpaper surface
                        setVideoSurfaceHolder(holder)

                        // Create media item from the video URI
                        val mediaItem = MediaItem.fromUri(uri)
                        setMediaItem(mediaItem)

                        // Enable infinite looping
                        repeatMode = Player.REPEAT_MODE_ALL

                        // Apply mute preference
                        val isMuted = PreferenceManager.isMuted(this@VideoWallpaperService)
                        volume = if (isMuted) 0f else 1f

                        // Apply scaling preference
                        val scaleType = PreferenceManager.getScaleType(this@VideoWallpaperService)
                        videoScalingMode = if (scaleType == PreferenceManager.SCALE_FIT) {
                            androidx.media3.common.C.VIDEO_SCALING_MODE_SCALE_TO_FIT
                        } else {
                            androidx.media3.common.C.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING
                        }

                        // Prepare and start playback
                        prepare()
                        playWhenReady = true
                    }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to initialize player", e)
            }
        }

        /** Pause playback to conserve battery when screen is off */
        private fun pausePlayer() {
            try {
                player?.playWhenReady = false
            } catch (e: Exception) {
                Log.w(TAG, "Error pausing player", e)
            }
        }

        /** Resume playback when screen turns on */
        private fun resumePlayer() {
            try {
                player?.playWhenReady = true
            } catch (e: Exception) {
                Log.w(TAG, "Error resuming player", e)
            }
        }

        /** Release ExoPlayer resources to prevent memory leaks */
        private fun releasePlayer() {
            try {
                player?.apply {
                    stop()
                    release()
                }
                player = null
            } catch (e: Exception) {
                Log.w(TAG, "Error releasing player", e)
            }
        }
    }
}
