# Keep ExoPlayer classes
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**

# Keep WallpaperService
-keep class com.videowallpaper.pro.service.** { *; }
