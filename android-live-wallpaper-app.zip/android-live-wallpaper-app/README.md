# Android Live Wallpaper App

This document outlines the architecture and project structure for a high-performance Android Live Wallpaper application. The app will allow users to select any video from their gallery and set it as a live wallpaper on both the home and lock screens, with features such as smooth looping, mute/unmute functionality, blur effects, and video quality adjustments, all while optimizing for low-end devices.

## 1. App Architecture

The application will follow a modular and layered architecture to ensure maintainability, scalability, and testability. Key components include:

- **`WallpaperService`**: The core component responsible for managing the live wallpaper lifecycle and rendering the video.
- **`WallpaperEngine`**: An inner class of `WallpaperService` that handles the drawing surface and user interactions.
- **`ExoPlayer`**: Used for efficient and smooth video playback, supporting various video formats and adaptive streaming.
- **`SettingsActivity`**: A UI component for user preferences, allowing selection of video, mute/unmute, blur intensity, and video quality.
- **`VideoSelectionActivity`**: A UI component for users to browse and select videos from their device's gallery.
- **`PermissionHandler`**: Manages runtime permissions, specifically for storage access.
- **`BlurEffectRenderer`**: Implements the blur effect using RenderScript or a modern alternative, applied to the video frame before rendering.
- **`VideoQualityManager`**: Handles dynamic adjustment of video resolution or bitrate based on user settings and device performance.

## 2. Project Structure

The project will adhere to standard Android project structure conventions, organized as follows:

```
android-live-wallpaper-app/
├── app/
│   ├── src/
│   │   ├── main/
│   │   │   ├── AndroidManifest.xml
│   │   │   ├── java/com/example/livewallpaper/
│   │   │   │   ├── WallpaperService.kt
│   │   │   │   ├── WallpaperEngine.kt
│   │   │   │   ├── SettingsActivity.kt
│   │   │   │   ├── VideoSelectionActivity.kt
│   │   │   │   ├── PermissionHandler.kt
│   │   │   │   ├── BlurEffectRenderer.kt
│   │   │   │   ├── VideoQualityManager.kt
│   │   │   │   └── utils/
│   │   │   │       └── Constants.kt
│   │   │   ├── res/
│   │   │   │   ├── drawable/
│   │   │   │   ├── layout/
│   │   │   │   │   ├── activity_settings.xml
│   │   │   │   │   └── activity_video_selection.xml
│   │   │   │   ├── mipmap/
│   │   │   │   ├── values/
│   │   │   │   │   ├── colors.xml
│   │   │   │   │   ├── strings.xml
│   │   │   │   │   └── themes.xml
│   │   │   │   └── xml/
│   │   │   │       └── wallpaper_settings.xml
│   │   ├── build.gradle
│   ├── gradle/
│   │   └── wrapper/
│   │       └── gradle-wrapper.properties
│   ├── gradlew
│   ├── gradlew.bat
│   └── settings.gradle
└── README.md
```

## 3. Key Features and Implementation Details

- **Video Selection**: Utilize `Intent.ACTION_GET_CONTENT` or `Intent.ACTION_PICK` to allow users to select videos from their gallery. Store the URI of the selected video using `SharedPreferences`.
- **Live Wallpaper Service**: Extend `WallpaperService` and implement `onCreateEngine()` to provide a custom `WallpaperEngine`. The `WallpaperEngine` will manage a `SurfaceHolder` for rendering and `ExoPlayer` for video playback.
- **ExoPlayer Integration**: Initialize `ExoPlayer` within the `WallpaperEngine`. Use `SurfaceView` or `TextureView` to display the video. Implement `Player.Listener` to handle playback events, including smooth looping (`setRepeatMode(Player.REPEAT_MODE_ALL)`).
- **Mute/Unmute**: Control `ExoPlayer`'s volume using `setVolume(0f)` for mute and `setVolume(1f)` for unmute, based on user preference stored in `SharedPreferences`.
- **Blur Effect**: Implement a blur effect by processing video frames. Modern alternatives to RenderScript include using `androidx.renderscript` (compatibility library) or OpenGL shaders. The blur intensity will be a user-adjustable setting.
- **Performance Optimization**: 
    - **Low Memory**: Release `ExoPlayer` resources when the wallpaper is not visible or paused. Use efficient image loading for thumbnails if needed.
    - **Reduced CPU**: Pause video playback when the wallpaper is not active (e.g., when another app is in the foreground). Adjust video quality dynamically.
    - **Efficient Rendering**: `SurfaceView` is generally preferred for live wallpapers due to its dedicated drawing surface, which can improve performance.
- **Video Quality Adjustment**: Offer options (Low, Medium, High) to transcode or select different renditions of the video if available, or dynamically adjust `ExoPlayer`'s `TrackSelector` parameters. This will be managed by `VideoQualityManager`.
- **Battery Optimization**: Implement proper lifecycle management for `ExoPlayer`, pausing playback when the wallpaper is not visible and releasing resources when the service is destroyed.
- **Permissions**: Request `READ_EXTERNAL_STORAGE` permission at runtime using `ActivityCompat.requestPermissions()`.
- **Android 8+ Compatibility**: Ensure all APIs used are compatible with Android 8 (API level 26) and higher. Utilize AndroidX libraries for backward compatibility.
- **Clean UI**: Design `SettingsActivity` and `VideoSelectionActivity` using Material Design components and principles for an intuitive user experience.

This detailed plan will guide the development process, ensuring all requirements are met systematically.

## 4. Setup Instructions

To set up and run this project in Android Studio, follow these steps:

1.  **Clone the Repository (or download the project files):**
    ```bash
    git clone <repository_url> # Replace with actual repository URL if applicable
    cd android-live-wallpaper-app
    ```
    If you downloaded a zip file, extract it to your desired location.

2.  **Open in Android Studio:**
    *   Launch Android Studio.
    *   Select `File > Open` and navigate to the `android-live-wallpaper-app` directory.
    *   Click `OK` or `Open`.

3.  **Sync Gradle Project:**
    *   Android Studio will automatically try to sync the Gradle project. If it doesn't, click the `Sync Project with Gradle Files` button (usually an elephant icon with a downward arrow) in the toolbar.
    *   Ensure you have an active internet connection for Gradle to download necessary dependencies.

4.  **Install SDK Components:**
    *   Android Studio might prompt you to install missing SDK components (e.g., platform SDK for API 34). Follow the prompts to install them.

5.  **Run on a Device or Emulator:**
    *   Connect an Android device with USB debugging enabled, or create and launch an Android Emulator.
    *   Select your target device/emulator from the dropdown menu in the toolbar.
    *   Click the `Run 'app'` button (green play icon) to build and install the application.

## 5. APK Build Instructions

To build a signed APK for release, follow these steps:

1.  **Generate a Signing Key (if you don't have one):**
    *   In Android Studio, go to `Build > Generate Signed Bundle / APK...`.
    *   Select `APK` and click `Next`.
    *   Click `Create new...` under `Key store path`.
    *   Fill in all the required information for your Key store, Key alias, Password, and Confirm. Remember to keep this information secure.
    *   Click `OK`.

2.  **Build the Signed APK:**
    *   Go to `Build > Generate Signed Bundle / APK...` again.
    *   Select `APK` and click `Next`.
    *   Choose your `Key store path`, `Key alias`, and enter your `Key store password` and `Key password`.
    *   Select `release` as the `Build variant`.
    *   Check `V1 (Jar Signature)` and `V2 (Full APK Signature)` for `Signature Versions`.
    *   Click `Finish`.

3.  **Locate the APK:**
    *   Android Studio will build the APK. Once finished, a notification will appear with a `locate` link. Click it to open the folder containing your signed APK (usually in `app/release/`).
    *   The APK file will be named something like `app-release.apk`.
