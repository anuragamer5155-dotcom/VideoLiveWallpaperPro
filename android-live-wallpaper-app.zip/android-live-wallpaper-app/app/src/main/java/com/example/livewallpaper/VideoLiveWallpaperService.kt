package com.example.livewallpaper

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.SurfaceTexture
import android.net.Uri
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.Surface
import android.view.SurfaceHolder
import com.example.livewallpaper.utils.Constants
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.source.DefaultMediaSourceFactory
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector
import com.google.android.exoplayer2.upstream.DefaultDataSource
import java.io.IOException
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class VideoLiveWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine {
        return VideoWallpaperEngine()
    }

    inner class VideoWallpaperEngine : Engine(), SharedPreferences.OnSharedPreferenceChangeListener, SurfaceTexture.OnFrameAvailableListener {

        private var exoPlayer: ExoPlayer? = null
        private var videoUri: Uri? = null
        private var isMuted: Boolean = false
        private var blurIntensity: Float = 0f
        private var videoQuality: Constants.VideoQuality = Constants.VideoQuality.MEDIUM
        private lateinit var sharedPreferences: SharedPreferences
        private var blurEffectRenderer: BlurEffectRenderer? = null
        private var videoQualityManager: VideoQualityManager? = null

        private var surfaceTexture: SurfaceTexture? = null
        private var surface: Surface? = null
        private var textureId = 0

        private val handler = Handler(Looper.getMainLooper())
        private val drawRunnable = Runnable { drawFrame() }

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            sharedPreferences = applicationContext.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)
            sharedPreferences.registerOnSharedPreferenceChangeListener(this)
            blurEffectRenderer = BlurEffectRenderer(applicationContext)
            videoQualityManager = VideoQualityManager()
            loadPreferences()
            setTouchEventsEnabled(false)
        }

        private fun loadPreferences() {
            val uriString = sharedPreferences.getString(Constants.VIDEO_URI_KEY, null)
            videoUri = uriString?.let { Uri.parse(it) }
            isMuted = sharedPreferences.getBoolean(Constants.MUTE_KEY, false)
            blurIntensity = sharedPreferences.getFloat(Constants.BLUR_INTENSITY_KEY, 0f)
            videoQuality = Constants.VideoQuality.valueOf(sharedPreferences.getString(Constants.VIDEO_QUALITY_KEY, Constants.VideoQuality.MEDIUM.name) ?: Constants.VideoQuality.MEDIUM.name)
            initPlayer()
        }

        private fun initPlayer() {
            releasePlayer()

            if (videoUri == null) return

            val trackSelector = videoQualityManager?.getTrackSelector(videoQuality) ?: DefaultTrackSelector(applicationContext)
            val loadControl = videoQualityManager?.getLoadControl(videoQuality) ?: DefaultLoadControl()

            exoPlayer = ExoPlayer.Builder(applicationContext)
                .setTrackSelector(trackSelector)
                .setLoadControl(loadControl)
                .build().apply {
                    setMediaSource(DefaultMediaSourceFactory(applicationContext).createMediaSource(MediaItem.fromUri(videoUri!!)))
                    repeatMode = Player.REPEAT_MODE_ALL
                    volume = if (isMuted) 0f else 1f
                    prepare()
                    playWhenReady = true
                }

            // Setup SurfaceTexture for OpenGL rendering
            textureId = createTexture()
            surfaceTexture = SurfaceTexture(textureId)
            surfaceTexture?.setOnFrameAvailableListener(this)
            surface = Surface(surfaceTexture)
            exoPlayer?.setVideoSurface(surface)

            drawFrame()
        }

        private fun releasePlayer() {
            exoPlayer?.release()
            exoPlayer = null
            surface?.release()
            surface = null
            surfaceTexture?.release()
            surfaceTexture = null
            // Delete texture
            val textures = IntArray(1)
            textures[0] = textureId
            GLES20.glDeleteTextures(1, textures, 0)
        }

        private fun createTexture(): Int {
            val textures = IntArray(1)
            GLES20.glGenTextures(1, textures, 0)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textures[0])
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
            return textures[0]
        }

        private fun drawFrame() {
            if (!surfaceHolder.isValid) return

            val canvas = surfaceHolder.lockCanvas()
            if (canvas != null) {
                try {
                    // Clear the canvas
                    canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)

                    surfaceTexture?.updateTexImage()
                    val transformMatrix = FloatArray(16)
                    surfaceTexture?.getTransformMatrix(transformMatrix)

                    // TODO: Render the video frame using OpenGL and apply blur
                    // For simplicity, this example will just draw a black background.
                    // Actual OpenGL rendering for video and blur would be complex and require a GLSurfaceView or custom GL rendering.
                    // For now, we'll simulate the blur by drawing a blurred bitmap if blurIntensity > 0

                    // This is a placeholder for actual video rendering.
                    // A more complete solution would involve setting up an OpenGL context and rendering the texture.
                    canvas.drawColor(Color.BLACK)

                    if (blurIntensity > 0) {
                        // This part is highly simplified. Real blur on video frames is complex.
                        // It would involve capturing a frame, converting to bitmap, blurring, and drawing.
                        // For a live wallpaper, this needs to be very efficient.
                        // A proper implementation would use OpenGL shaders for blur.
                        // For demonstration, we'll just draw a semi-transparent overlay.
                        val paint = Paint()
                        paint.color = Color.argb((blurIntensity * 10).toInt().coerceIn(0, 255), 0, 0, 0) // Simulate blur with a dark overlay
                        canvas.drawRect(0f, 0f, canvas.width.toFloat(), canvas.height.toFloat(), paint)
                    }

                } finally {
                    surfaceHolder.unlockCanvasAndPost(canvas)
                }
            }
            handler.removeCallbacks(drawRunnable)
            handler.postDelayed(drawRunnable, 1000L / 60L) // Target 60 FPS
        }

        override fun onVisibilityChanged(visible: Boolean) {
            super.onVisibilityChanged(visible)
            if (visible) {
                exoPlayer?.playWhenReady = true
                handler.post(drawRunnable)
            } else {
                exoPlayer?.playWhenReady = false
                handler.removeCallbacks(drawRunnable)
            }
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            // Handle surface size changes if necessary
        }

        override fun onSurfaceCreated(holder: SurfaceHolder) {
            super.onSurfaceCreated(holder)
            // This is handled by the WallpaperService's onCreateEngine
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            super.onSurfaceDestroyed(holder)
            releasePlayer()
            handler.removeCallbacks(drawRunnable)
        }

        override fun onDestroy() {
            super.onDestroy()
            sharedPreferences.unregisterOnSharedPreferenceChangeListener(this)
            releasePlayer()
            blurEffectRenderer?.release()
            handler.removeCallbacks(drawRunnable)
        }

        override fun onSharedPreferenceChanged(sharedPreferences: SharedPreferences?, key: String?) {
            when (key) {
                Constants.VIDEO_URI_KEY -> {
                    val uriString = sharedPreferences?.getString(Constants.VIDEO_URI_KEY, null)
                    videoUri = uriString?.let { Uri.parse(it) }
                    initPlayer()
                }
                Constants.MUTE_KEY -> {
                    isMuted = sharedPreferences?.getBoolean(Constants.MUTE_KEY, false) ?: false
                    exoPlayer?.volume = if (isMuted) 0f else 1f
                }
                Constants.BLUR_INTENSITY_KEY -> {
                    blurIntensity = sharedPreferences?.getFloat(Constants.BLUR_INTENSITY_KEY, 0f) ?: 0f
                    // Re-render or apply blur effect if possible without re-initializing player
                    // This might require custom GLSurfaceView rendering or similar
                }
                Constants.VIDEO_QUALITY_KEY -> {
                    videoQuality = Constants.VideoQuality.valueOf(sharedPreferences?.getString(Constants.VIDEO_QUALITY_KEY, Constants.VideoQuality.MEDIUM.name) ?: Constants.VideoQuality.MEDIUM.name)
                    initPlayer()
                }
            }
        }

        override fun onFrameAvailable(surfaceTexture: SurfaceTexture?) {
            // A new frame is available, request a redraw
            handler.post(drawRunnable)
        }
    }
}
