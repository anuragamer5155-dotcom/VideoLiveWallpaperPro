package com.example.livewallpaper

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class VideoSelectionActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // This activity is primarily for handling video selection result
        // The actual video picking intent is launched from SettingsActivity
    }

    // This activity might not be strictly necessary if video selection is handled directly in SettingsActivity
    // However, if more complex video browsing/preview is needed, this would be the place.
    // For now, the video selection is handled by SettingsActivity using ActivityResultContracts.
}
