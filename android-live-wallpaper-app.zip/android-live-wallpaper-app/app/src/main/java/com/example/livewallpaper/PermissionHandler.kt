package com.example.livewallpaper

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.livewallpaper.utils.Constants

class PermissionHandler(private val activity: Activity) {

    fun checkAndRequestPermissions() {
        if (ContextCompat.checkSelfPermission(activity, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                activity,
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),
                Constants.REQUEST_CODE_PERMISSIONS
            )
        }
    }

    fun hasPermissions(): Boolean {
        return ContextCompat.checkSelfPermission(activity, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
    }

    companion object {
        fun onRequestPermissionsResult(requestCode: Int, grantResults: IntArray, onGranted: () -> Unit, onDenied: () -> Unit) {
            if (requestCode == Constants.REQUEST_CODE_PERMISSIONS) {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    onGranted()
                } else {
                    onDenied()
                }
            }
        }
    }
}
