package com.example.livewallpaper

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.net.Uri
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.service.wallpaper.WallpaperService
import android.view.Surface
import android.view.SurfaceHolder
import com.example.livewallpaper.utils.Constants
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.source.DefaultMediaSourceFactory
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector
import com.google.android.exoplayer2.upstream.DefaultDataSource
import java.io.IOException
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class VideoLiveWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine {
        return VideoWallpaperEngine()
    }

    inner class VideoWallpaperEngine : Engine(), SharedPreferences.OnSharedPreferenceChangeListener {

        private var exoPlayer: ExoPlayer? = null
        private var videoUri: Uri? = null
        private var isMuted: Boolean = false
        private var blurIntensity: Float = 0f
        private var videoQuality: Constants.VideoQuality = Constants.VideoQuality.MEDIUM
        private lateinit var sharedPreferences: SharedPreferences
        private var blurEffectRenderer: BlurEffectRenderer? = null
        private var videoQualityManager: VideoQualityManager? = null

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            sharedPreferences = applicationContext.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)
            sharedPreferences.registerOnSharedPreferenceChangeListener(this)
            blurEffectRenderer = BlurEffectRenderer(applicationContext)
            videoQualityManager = VideoQualityManager()
            loadPreferences()
            setTouchEventsEnabled(false)
        }

        private fun loadPreferences() {
            val uriString = sharedPreferences.getString(Constants.VIDEO_URI_KEY, null)
            videoUri = uriString?.let { Uri.parse(it) }
            isMuted = sharedPreferences.getBoolean(Constants.MUTE_KEY, false)
            blurIntensity = sharedPreferences.getFloat(Constants.BLUR_INTENSITY_KEY, 0f)
            videoQuality = Constants.VideoQuality.valueOf(sharedPreferences.getString(Constants.VIDEO_QUALITY_KEY, Constants.VideoQuality.MEDIUM.name) ?: Constants.VideoQuality.MEDIUM.name)
            initPlayer()
        }

        private fun initPlayer() {
            if (exoPlayer == null && videoUri != null) {
                val trackSelector = videoQualityManager?.getTrackSelector(videoQuality) ?: DefaultTrackSelector(applicationContext)
                val loadControl = videoQualityManager?.getLoadControl(videoQuality) ?: DefaultLoadControl()

                exoPlayer = ExoPlayer.Builder(applicationContext)
                    .setTrackSelector(trackSelector)
                    .setLoadControl(loadControl)
                    .build().apply {
                        setMediaSource(DefaultMediaSourceFactory(applicationContext).createMediaSource(MediaItem.fromUri(videoUri!!)))
                        repeatMode = Player.REPEAT_MODE_ALL
                        volume = if (isMuted) 0f else 1f
                        setVideoSurface(Surface(surfaceHolder.surfaceFrame))
                        prepare()
                        playWhenReady = true
                    }
            } else if (exoPlayer != null) {
                // Update existing player settings if preferences changed
                exoPlayer?.volume = if (isMuted) 0f else 1f
                // Re-initialize player if video URI or quality changes significantly
                // For quality changes, it might be better to re-create the player or adjust track selector parameters
            }
        }

        private fun releasePlayer() {
            exoPlayer?.release()
            exoPlayer = null
        }

        override fun onVisibilityChanged(visible: Boolean) {
            super.onVisibilityChanged(visible)
            if (visible) {
                exoPlayer?.playWhenReady = true
            } else {
                exoPlayer?.playWhenReady = false
            }
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            // Handle surface size changes if necessary
        }

        override fun onSurfaceCreated(holder: SurfaceHolder) {
            super.onSurfaceCreated(holder)
            initPlayer()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            super.onSurfaceDestroyed(holder)
            releasePlayer()
        }

        override fun onDestroy() {
            super.onDestroy()
            sharedPreferences.unregisterOnSharedPreferenceChangeListener(this)
            releasePlayer()
            blurEffectRenderer?.release()
        }

        override fun onSharedPreferenceChanged(sharedPreferences: SharedPreferences?, key: String?) {
            when (key) {
                Constants.VIDEO_URI_KEY -> {
                    val uriString = sharedPreferences?.getString(Constants.VIDEO_URI_KEY, null)
                    videoUri = uriString?.let { Uri.parse(it) }
                    releasePlayer()
                    initPlayer()
                }
                Constants.MUTE_KEY -> {
                    isMuted = sharedPreferences?.getBoolean(Constants.MUTE_KEY, false) ?: false
                    exoPlayer?.volume = if (isMuted) 0f else 1f
                }
                Constants.BLUR_INTENSITY_KEY -> {
                    blurIntensity = sharedPreferences?.getFloat(Constants.BLUR_INTENSITY_KEY, 0f) ?: 0f
                    // Re-render or apply blur effect if possible without re-initializing player
                    // This might require custom GLSurfaceView rendering or similar
                }
                Constants.VIDEO_QUALITY_KEY -> {
                    videoQuality = Constants.VideoQuality.valueOf(sharedPreferences?.getString(Constants.VIDEO_QUALITY_KEY, Constants.VideoQuality.MEDIUM.name) ?: Constants.VideoQuality.MEDIUM.name)
                    releasePlayer()
                    initPlayer()
                }
            }
        }
    }
}
