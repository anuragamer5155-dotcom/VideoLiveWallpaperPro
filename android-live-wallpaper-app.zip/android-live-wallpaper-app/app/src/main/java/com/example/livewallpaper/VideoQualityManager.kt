package com.example.livewallpaper

import com.example.livewallpaper.utils.Constants
import com.google.android.exoplayer2.DefaultLoadControl
import com.google.android.exoplayer2.LoadControl
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector
import com.google.android.exoplayer2.trackselection.TrackSelector

class VideoQualityManager {

    fun getLoadControl(quality: Constants.VideoQuality): LoadControl {
        return when (quality) {
            Constants.VideoQuality.LOW -> DefaultLoadControl.Builder()
                .setBufferDurationsMs(5000, 10000, 2500, 5000) // min, max, start, back buffer
                .build()
            Constants.VideoQuality.MEDIUM -> DefaultLoadControl.Builder()
                .setBufferDurationsMs(10000, 20000, 5000, 10000)
                .build()
            Constants.VideoQuality.HIGH -> DefaultLoadControl.Builder()
                .setBufferDurationsMs(15000, 30000, 7500, 15000)
                .build()
        }
    }

    fun getTrackSelector(quality: Constants.VideoQuality): TrackSelector {
        val parametersBuilder = DefaultTrackSelector.Parameters.Builder()

        when (quality) {
            Constants.VideoQuality.LOW -> {
                parametersBuilder.setMaxVideoSize(640, 480) // Limit to 480p
                    .setMaxVideoBitrate(800000) // 0.8 Mbps
            }
            Constants.VideoQuality.MEDIUM -> {
                parametersBuilder.setMaxVideoSize(1280, 720) // Limit to 720p
                    .setMaxVideoBitrate(2500000) // 2.5 Mbps
            }
            Constants.VideoQuality.HIGH -> {
                parametersBuilder.setMaxVideoSizeSd() // No specific limit, uses device capabilities
                    .setMaxVideoBitrate(5000000) // 5 Mbps
            }
        }
        return DefaultTrackSelector(parametersBuilder.build())
    }
}
