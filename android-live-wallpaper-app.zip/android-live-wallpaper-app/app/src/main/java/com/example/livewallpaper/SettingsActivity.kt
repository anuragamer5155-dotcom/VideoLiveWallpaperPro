package com.example.livewallpaper

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import android.app.WallpaperManager
import android.content.ComponentName
import com.example.livewallpaper.utils.Constants

class SettingsActivity : AppCompatActivity() {

    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var btnSelectVideo: Button
    private lateinit var switchMute: Switch
    private lateinit var seekBarBlur: SeekBar
    private lateinit var tvBlurValue: TextView
    private lateinit var btnSetWallpaper: Button
    private lateinit var btnVideoQualityLow: Button
    private lateinit var btnVideoQualityMedium: Button
    private lateinit var btnVideoQualityHigh: Button

    private val permissionHandler = PermissionHandler(this)

    private val selectVideoLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == RESULT_OK) {
            it.data?.data?.let { uri ->
                saveVideoUri(uri)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        sharedPreferences = getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)

        btnSelectVideo = findViewById(R.id.btn_select_video)
        switchMute = findViewById(R.id.switch_mute)
        seekBarBlur = findViewById(R.id.seek_bar_blur)
        tvBlurValue = findViewById(R.id.tv_blur_value)
        btnSetWallpaper = findViewById(R.id.btn_set_wallpaper)
        btnVideoQualityLow = findViewById(R.id.btn_quality_low)
        btnVideoQualityMedium = findViewById(R.id.btn_quality_medium)
        btnVideoQualityHigh = findViewById(R.id.btn_quality_high)

        setupListeners()
        loadSettings()
    }

    private fun setupListeners() {
        btnSelectVideo.setOnClickListener { 
            if (permissionHandler.hasPermissions()) {
                openVideoPicker()
            } else {
                permissionHandler.checkAndRequestPermissions()
            }
        }

        switchMute.setOnCheckedChangeListener { _, isChecked ->
            sharedPreferences.edit().putBoolean(Constants.MUTE_KEY, isChecked).apply()
        }

        seekBarBlur.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                tvBlurValue.text = progress.toString()
                sharedPreferences.edit().putFloat(Constants.BLUR_INTENSITY_KEY, progress.toFloat()).apply()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        btnSetWallpaper.setOnClickListener { 
            val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
            intent.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, ComponentName(this, VideoLiveWallpaperService::class.java))
            startActivity(intent)
        }

        btnVideoQualityLow.setOnClickListener { setVideoQuality(Constants.VideoQuality.LOW) }
        btnVideoQualityMedium.setOnClickListener { setVideoQuality(Constants.VideoQuality.MEDIUM) }
        btnVideoQualityHigh.setOnClickListener { setVideoQuality(Constants.VideoQuality.HIGH) }
    }

    private fun loadSettings() {
        switchMute.isChecked = sharedPreferences.getBoolean(Constants.MUTE_KEY, false)
        val blurIntensity = sharedPreferences.getFloat(Constants.BLUR_INTENSITY_KEY, 0f).toInt()
        seekBarBlur.progress = blurIntensity
        tvBlurValue.text = blurIntensity.toString()
        updateVideoQualityButtons(Constants.VideoQuality.valueOf(sharedPreferences.getString(Constants.VIDEO_QUALITY_KEY, Constants.VideoQuality.MEDIUM.name) ?: Constants.VideoQuality.MEDIUM.name))
    }

    private fun openVideoPicker() {
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "video/*"
        selectVideoLauncher.launch(intent)
    }

    private fun saveVideoUri(uri: Uri) {
        // Persist URI permissions
        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        sharedPreferences.edit().putString(Constants.VIDEO_URI_KEY, uri.toString()).apply()
    }

    private fun setVideoQuality(quality: Constants.VideoQuality) {
        sharedPreferences.edit().putString(Constants.VIDEO_QUALITY_KEY, quality.name).apply()
        updateVideoQualityButtons(quality)
    }

    private fun updateVideoQualityButtons(currentQuality: Constants.VideoQuality) {
        btnVideoQualityLow.isEnabled = currentQuality != Constants.VideoQuality.LOW
        btnVideoQualityMedium.isEnabled = currentQuality != Constants.VideoQuality.MEDIUM
        btnVideoQualityHigh.isEnabled = currentQuality != Constants.VideoQuality.HIGH
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        PermissionHandler.onRequestPermissionsResult(requestCode, grantResults,
            onGranted = { openVideoPicker() },
            onDenied = { /* Handle permission denied, e.g., show a message */ }
        )
    }
}
