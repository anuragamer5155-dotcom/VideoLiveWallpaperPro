package com.example.livewallpaper

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.renderscript.Allocation
import android.renderscript.Element
import android.renderscript.RenderScript
import android.renderscript.ScriptIntrinsicBlur

class BlurEffectRenderer(private val context: Context) {

    private var renderScript: RenderScript? = null
    private var scriptIntrinsicBlur: ScriptIntrinsicBlur? = null
    private var inAllocation: Allocation? = null
    private var outAllocation: Allocation? = null

    init {
        try {
            renderScript = RenderScript.create(context)
            scriptIntrinsicBlur = ScriptIntrinsicBlur.create(renderScript, Element.U8_4(renderScript))
        } catch (e: Exception) {
            e.printStackTrace()
            // Fallback or error handling if RenderScript is not available
        }
    }

    fun blurBitmap(bitmap: Bitmap, blurRadius: Float): Bitmap? {
        if (renderScript == null || scriptIntrinsicBlur == null) {
            return null // RenderScript not initialized
        }

        val outputBitmap = Bitmap.createBitmap(bitmap.width, bitmap.height, bitmap.config)

        inAllocation = Allocation.createFromBitmap(renderScript, bitmap, Allocation.MipmapControl.MIPMAP_NONE, Allocation.USAGE_SCRIPT)
        outAllocation = Allocation.createFromBitmap(renderScript, outputBitmap, Allocation.MipmapControl.MIPMAP_NONE, Allocation.USAGE_SCRIPT)

        scriptIntrinsicBlur?.setRadius(blurRadius.coerceIn(0.0f, 25.0f)) // Radius must be 0 < radius <= 25
        scriptIntrinsicBlur?.setInput(inAllocation)
        scriptIntrinsicBlur?.forEach(outAllocation)
        outAllocation?.copyTo(outputBitmap)

        return outputBitmap
    }

    fun release() {
        scriptIntrinsicBlur?.destroy()
        renderScript?.destroy()
        inAllocation?.destroy()
        outAllocation?.destroy()
        scriptIntrinsicBlur = null
        renderScript = null
        inAllocation = null
        outAllocation = null
    }
}
