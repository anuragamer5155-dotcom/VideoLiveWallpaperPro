package com.example.livewallpaper.utils

object Constants {
    const val PREFS_NAME = "live_wallpaper_prefs"
    const val VIDEO_URI_KEY = "video_uri"
    const val MUTE_KEY = "mute_key"
    const val BLUR_INTENSITY_KEY = "blur_intensity_key"
    const val VIDEO_QUALITY_KEY = "video_quality_key"
    const val REQUEST_CODE_SELECT_VIDEO = 1001
    const val REQUEST_CODE_PERMISSIONS = 1002

    enum class VideoQuality {
        LOW,
        MEDIUM,
        HIGH
    }
}
